import { Player } from '../types/game';
import { GOALKEEPERS } from './players/goalkeepers';
import { DEFENDERS } from './players/defenders';
import { MIDFIELDERS } from './players/midfielders';
import { FORWARDS } from './players/forwards';

export { GOALKEEPERS } from './players/goalkeepers';
export { DEFENDERS } from './players/defenders';
export { MIDFIELDERS } from './players/midfielders';
export { FORWARDS } from './players/forwards';

// Combined database of 500+ authentic players (at least 110+ per position category)
export const PLAYERS_DB: Player[] = [
  ...GOALKEEPERS,
  ...DEFENDERS,
  ...MIDFIELDERS,
  ...FORWARDS,
];

// Helper to get total counts by category
export const PLAYER_COUNTS = {
  POR: GOALKEEPERS.length,
  DEF: DEFENDERS.length,
  MED: MIDFIELDERS.length,
  DEL: FORWARDS.length,
  TOTAL: GOALKEEPERS.length + DEFENDERS.length + MIDFIELDERS.length + FORWARDS.length,
};
