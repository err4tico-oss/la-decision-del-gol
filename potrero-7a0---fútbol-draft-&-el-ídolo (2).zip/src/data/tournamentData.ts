import { TournamentTeam, TournamentType, MatchStageInfo } from '../types/game';

// ================= CLUBS EUROPEOS (CHAMPIONS LEAGUE) =================
export const CLUBS_POOL: TournamentTeam[] = [
  { id: 'realmadrid', name: 'Real Madrid', shortName: 'Real Madrid', ovr: 91, logoEmoji: '👑', countryOrCity: 'España', starPlayer: 'Mbappé & Vinícius Jr', color: '#EEEEEF' },
  { id: 'mancity', name: 'Manchester City', shortName: 'Man. City', ovr: 90, logoEmoji: '⛵', countryOrCity: 'Inglaterra', starPlayer: 'Haaland & De Bruyne', color: '#6CABDD' },
  { id: 'bayern', name: 'Bayern Múnich', shortName: 'Bayern', ovr: 88, logoEmoji: '🔴', countryOrCity: 'Alemania', starPlayer: 'Harry Kane & Musiala', color: '#DC052D' },
  { id: 'arsenal', name: 'Arsenal FC', shortName: 'Arsenal', ovr: 87, logoEmoji: '🔴', countryOrCity: 'Inglaterra', starPlayer: 'Saka & Saliba', color: '#EF0107' },
  { id: 'liverpool', name: 'Liverpool FC', shortName: 'Liverpool', ovr: 88, logoEmoji: '🦅', countryOrCity: 'Inglaterra', starPlayer: 'Mohamed Salah', color: '#C8102E' },
  { id: 'barcelona', name: 'FC Barcelona', shortName: 'Barcelona', ovr: 87, logoEmoji: '🔵', countryOrCity: 'España', starPlayer: 'Lamine Yamal & Pedri', color: '#004D98' },
  { id: 'psg', name: 'Paris Saint-Germain', shortName: 'PSG', ovr: 85, logoEmoji: '🗼', countryOrCity: 'Francia', starPlayer: 'Dembélé & Barcola', color: '#002B7F' },
  { id: 'inter', name: 'Inter de Milán', shortName: 'Inter', ovr: 86, logoEmoji: '🐍', countryOrCity: 'Italia', starPlayer: 'Lautaro Martínez', color: '#001489' },
  { id: 'bayerleverkusen', name: 'Bayer Leverkusen', shortName: 'Leverkusen', ovr: 86, logoEmoji: '💊', countryOrCity: 'Alemania', starPlayer: 'Florian Wirtz', color: '#E32219' },
  { id: 'atletico', name: 'Atlético de Madrid', shortName: 'Atlético', ovr: 85, logoEmoji: '🐻', countryOrCity: 'España', starPlayer: 'Julián Álvarez & Griezmann', color: '#CB3524' },
  { id: 'juventus', name: 'Juventus FC', shortName: 'Juventus', ovr: 83, logoEmoji: '🦓', countryOrCity: 'Italia', starPlayer: 'Vlahović & Koopmeiners', color: '#000000' },
  { id: 'dortmund', name: 'Borussia Dortmund', shortName: 'Dortmund', ovr: 83, logoEmoji: '🐝', countryOrCity: 'Alemania', starPlayer: 'Adeyemi & Guirassy', color: '#FDE100' },
  { id: 'milan', name: 'AC Milan', shortName: 'Milan', ovr: 82, logoEmoji: '🔴', countryOrCity: 'Italia', starPlayer: 'Rafael Leão', color: '#FB090B' },
  { id: 'astonvilla', name: 'Aston Villa', shortName: 'Aston Villa', ovr: 82, logoEmoji: '🦁', countryOrCity: 'Inglaterra', starPlayer: 'Dibu Martínez & Watkins', color: '#95BFE5' },
  { id: 'sporting', name: 'Sporting CP', shortName: 'Sporting', ovr: 81, logoEmoji: '🦁', countryOrCity: 'Portugal', starPlayer: 'Gyökeres', color: '#008057' },
  { id: 'atalanta', name: 'Atalanta BC', shortName: 'Atalanta', ovr: 82, logoEmoji: '🔵', countryOrCity: 'Italia', starPlayer: 'Lookman & Retegui', color: '#1E71B8' },
  { id: 'benfica', name: 'SL Benfica', shortName: 'Benfica', ovr: 80, logoEmoji: '🦅', countryOrCity: 'Portugal', starPlayer: 'Ángel Di María', color: '#E80000' },
  { id: 'monaco', name: 'AS Mónaco', shortName: 'Mónaco', ovr: 80, logoEmoji: '👑', countryOrCity: 'Francia', starPlayer: 'Golovin & Balogun', color: '#E2001A' },
  { id: 'leipzig', name: 'RB Leipzig', shortName: 'Leipzig', ovr: 81, logoEmoji: '🐂', countryOrCity: 'Alemania', starPlayer: 'Xavi Simons & Šeško', color: '#E01E37' },
  { id: 'feyenoord', name: 'Feyenoord', shortName: 'Feyenoord', ovr: 78, logoEmoji: '🔴', countryOrCity: 'Países Bajos', starPlayer: 'Giménez', color: '#E30613' },
  { id: 'psv', name: 'PSV Eindhoven', shortName: 'PSV', ovr: 79, logoEmoji: '💡', countryOrCity: 'Países Bajos', starPlayer: 'De Jong & Bakayoko', color: '#ED1B24' },
  { id: 'celtic', name: 'Celtic FC', shortName: 'Celtic', ovr: 76, logoEmoji: '🍀', countryOrCity: 'Escocia', starPlayer: 'McGregor & Maeda', color: '#008559' },
  { id: 'girona', name: 'Girona FC', shortName: 'Girona', ovr: 77, logoEmoji: '🔴', countryOrCity: 'España', starPlayer: 'Tsygankov', color: '#CD1227' },
  { id: 'stuttgart', name: 'VfB Stuttgart', shortName: 'Stuttgart', ovr: 78, logoEmoji: '⚪', countryOrCity: 'Alemania', starPlayer: 'Undav & Demirović', color: '#E30613' },
];

// ================= SELECCIONES NACIONALES (MUNDIAL 48 EQUIPOS) =================
export const NATIONS_POOL: TournamentTeam[] = [
  { id: 'argentina', name: 'Argentina', shortName: 'Argentina', ovr: 90, logoEmoji: '🇦🇷', countryOrCity: 'Sudamérica', starPlayer: 'Messi & Lautaro', color: '#74ACDF' },
  { id: 'francia', name: 'Francia', shortName: 'Francia', ovr: 90, logoEmoji: '🇫🇷', countryOrCity: 'Europa', starPlayer: 'Mbappé & Griezmann', color: '#002654' },
  { id: 'brasil', name: 'Brasil', shortName: 'Brasil', ovr: 88, logoEmoji: '🇧🇷', countryOrCity: 'Sudamérica', starPlayer: 'Vinícius Jr & Rodrygo', color: '#FEDF00' },
  { id: 'espana', name: 'España', shortName: 'España', ovr: 89, logoEmoji: '🇪🇸', countryOrCity: 'Europa', starPlayer: 'Lamine Yamal & Rodri', color: '#C60B1E' },
  { id: 'inglaterra', name: 'Inglaterra', shortName: 'Inglaterra', ovr: 88, logoEmoji: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', countryOrCity: 'Europa', starPlayer: 'Bellingham & Kane', color: '#CF081F' },
  { id: 'alemania', name: 'Alemania', shortName: 'Alemania', ovr: 87, logoEmoji: '🇩🇪', countryOrCity: 'Europa', starPlayer: 'Musiala & Wirtz', color: '#000000' },
  { id: 'portugal', name: 'Portugal', shortName: 'Portugal', ovr: 86, logoEmoji: '🇵🇹', countryOrCity: 'Europa', starPlayer: 'Bruno Fernandes & Leão', color: '#046A38' },
  { id: 'paisesbajos', name: 'Países Bajos', shortName: 'Holanda', ovr: 85, logoEmoji: '🇳🇱', countryOrCity: 'Europa', starPlayer: 'Van Dijk & Simons', color: '#FF6200' },
  { id: 'uruguay', name: 'Uruguay', shortName: 'Uruguay', ovr: 85, logoEmoji: '🇺🇾', countryOrCity: 'Sudamérica', starPlayer: 'Valverde & Núñez', color: '#0038A8' },
  { id: 'colombia', name: 'Colombia', shortName: 'Colombia', ovr: 84, logoEmoji: '🇨🇴', countryOrCity: 'Sudamérica', starPlayer: 'Luis Díaz & James', color: '#FCD116' },
  { id: 'italia', name: 'Italia', shortName: 'Italia', ovr: 84, logoEmoji: '🇮🇹', countryOrCity: 'Europa', starPlayer: 'Barella & Bastoni', color: '#0064AA' },
  { id: 'belgica', name: 'Bélgica', shortName: 'Bélgica', ovr: 83, logoEmoji: '🇧🇪', countryOrCity: 'Europa', starPlayer: 'De Bruyne & Doku', color: '#ED2939' },
  { id: 'croacia', name: 'Croacia', shortName: 'Croacia', ovr: 82, logoEmoji: '🇭🇷', countryOrCity: 'Europa', starPlayer: 'Luka Modrić & Gvardiol', color: '#FF0000' },
  { id: 'marruecos', name: 'Marruecos', shortName: 'Marruecos', ovr: 82, logoEmoji: '🇲🇦', countryOrCity: 'África', starPlayer: 'Hakimi & Brahim', color: '#C1272D' },
  { id: 'japon', name: 'Japón', shortName: 'Japón', ovr: 80, logoEmoji: '🇯🇵', countryOrCity: 'Asia', starPlayer: 'Mitoma & Kubo', color: '#002B7F' },
  { id: 'senegal', name: 'Senegal', shortName: 'Senegal', ovr: 79, logoEmoji: '🇸🇳', countryOrCity: 'África', starPlayer: 'Sadio Mané & Jackson', color: '#00853F' },
  { id: 'mexico', name: 'México', shortName: 'México', ovr: 78, logoEmoji: '🇲🇽', countryOrCity: 'Norteamérica', starPlayer: 'Santi Giménez & Edson', color: '#006847' },
  { id: 'estadosunidos', name: 'Estados Unidos', shortName: 'EE.UU.', ovr: 79, logoEmoji: '🇺🇸', countryOrCity: 'Norteamérica', starPlayer: 'Pulisic & McKennie', color: '#3C3B6E' },
  { id: 'suiza', name: 'Suiza', shortName: 'Suiza', ovr: 80, logoEmoji: '🇨🇭', countryOrCity: 'Europa', starPlayer: 'Xhaka & Akanji', color: '#D52B1E' },
  { id: 'ecuador', name: 'Ecuador', shortName: 'Ecuador', ovr: 79, logoEmoji: '🇪🇨', countryOrCity: 'Sudamérica', starPlayer: 'Moisés Caicedo & Hincapié', color: '#FFD100' },
  { id: 'nigeria', name: 'Nigeria', shortName: 'Nigeria', ovr: 78, logoEmoji: '🇳🇬', countryOrCity: 'África', starPlayer: 'Osimhen & Lookman', color: '#008751' },
  { id: 'coreadelsur', name: 'Corea del Sur', shortName: 'Corea', ovr: 78, logoEmoji: '🇰🇷', countryOrCity: 'Asia', starPlayer: 'Son Heung-min', color: '#C60C30' },
  { id: 'chile', name: 'Chile', shortName: 'Chile', ovr: 76, logoEmoji: '🇨🇱', countryOrCity: 'Sudamérica', starPlayer: 'Alexis Sánchez', color: '#0039A6' },
  { id: 'costademarfil', name: 'Costa de Marfil', shortName: 'C. de Marfil', ovr: 78, logoEmoji: '🇨🇮', countryOrCity: 'África', starPlayer: 'Kessié & Haller', color: '#F77F00' },
];

// Helper to draw a completely random rival from the pool
export function drawRandomRival(tournamentType: TournamentType, excludedIds: string[] = []): TournamentTeam {
  const pool = tournamentType === 'champions' ? CLUBS_POOL : NATIONS_POOL;
  const available = pool.filter((t) => !excludedIds.includes(t.id));
  const candidatePool = available.length > 0 ? available : pool;
  const randomIndex = Math.floor(Math.random() * candidatePool.length);
  return candidatePool[randomIndex];
}

// ================= CAMPAIGN STRUCTURE: MUNDIAL (8 PARTIDOS) =================
// 3 partidos de Fase de Grupos + Dieciseisavos (R32) + Octavos (R16) + Cuartos (QF) + Semis + Gran Final = 8 Partidos
export const MUNDIAL_SCHEDULE: { stageName: string; isKnockout: boolean }[] = [
  { stageName: 'Fase de Grupos · Fecha 1', isKnockout: false },
  { stageName: 'Fase de Grupos · Fecha 2', isKnockout: false },
  { stageName: 'Fase de Grupos · Fecha 3 (Definitoria)', isKnockout: false },
  { stageName: 'Dieciseisavos de Final (Ronda de 32)', isKnockout: true },
  { stageName: 'Octavos de Final', isKnockout: true },
  { stageName: 'Cuartos de Final', isKnockout: true },
  { stageName: 'Semifinales del Mundo', isKnockout: true },
  { stageName: '¡Gran Final de la Copa del Mundo!', isKnockout: true },
];

// ================= CAMPAIGN STRUCTURE: CHAMPIONS LEAGUE (15 PARTIDOS) =================
// 8 partidos de Fase de Liga + Octavos (Ida y Vuelta) + Cuartos (Ida y Vuelta) + Semis (Ida y Vuelta) + Gran Final = 15 Partidos
export const CHAMPIONS_SCHEDULE: { stageName: string; isKnockout: boolean; leg?: 'ida' | 'vuelta' | 'unica' }[] = [
  { stageName: 'Fase de Liga · Jornada 1 de 8', isKnockout: false },
  { stageName: 'Fase de Liga · Jornada 2 de 8', isKnockout: false },
  { stageName: 'Fase de Liga · Jornada 3 de 8', isKnockout: false },
  { stageName: 'Fase de Liga · Jornada 4 de 8', isKnockout: false },
  { stageName: 'Fase de Liga · Jornada 5 de 8', isKnockout: false },
  { stageName: 'Fase de Liga · Jornada 6 de 8', isKnockout: false },
  { stageName: 'Fase de Liga · Jornada 7 de 8', isKnockout: false },
  { stageName: 'Fase de Liga · Jornada 8 de 8 (Cierre de Liga)', isKnockout: false },
  { stageName: 'Octavos de Final · Partido de Ida', isKnockout: false, leg: 'ida' },
  { stageName: 'Octavos de Final · Partido de Vuelta', isKnockout: true, leg: 'vuelta' },
  { stageName: 'Cuartos de Final · Partido de Ida', isKnockout: false, leg: 'ida' },
  { stageName: 'Cuartos de Final · Partido de Vuelta', isKnockout: true, leg: 'vuelta' },
  { stageName: 'Semifinales · Partido de Ida', isKnockout: false, leg: 'ida' },
  { stageName: 'Semifinales · Partido de Vuelta', isKnockout: true, leg: 'vuelta' },
  { stageName: '¡Gran Final de la UEFA Champions League!', isKnockout: true, leg: 'unica' },
];
