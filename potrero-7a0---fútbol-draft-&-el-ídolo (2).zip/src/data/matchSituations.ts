import { MatchSituation, SituationZone, Player, SituationOption } from '../types/game';

interface RawTemplate {
  zone: SituationZone;
  title: string;
  scenarioText: (att?: string, def?: string, gk?: string) => string;
  options: {
    title: string;
    description: string;
    internalWeight: number; // Tough base success rates (0.30 - 0.48)
    statRequired: 'pace' | 'shooting' | 'passing' | 'dribbling' | 'defending' | 'physical';
    successText: (star?: string) => string;
    failText: (star?: string) => string;
    isGoalIfSuccess: boolean;
    isGoalIfFail: boolean;
  }[];
}

const TEMPLATES_POOL: RawTemplate[] = [
  // ===================== SITUACIONES DE ATAQUE =====================
  {
    zone: 'ataque',
    title: 'Mano a Mano con Achique Agresivo del Guardameta',
    scenarioText: (att = 'Tu delantero') =>
      `¡Pase entre líneas con marca asfixiante! ${att} pica al espacio libre mientras dos centrales le respiran en la nuca y el portero rival sale como una fiera a achicar el ángulo.`,
    options: [
      {
        title: 'Definición Rasante al Palo Lejano',
        description: 'Abrir el pie con precisión buscando la base del poste lejano soportando el choque del zaguero.',
        internalWeight: 0.38,
        statRequired: 'shooting',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: (att = 'Tu delantero') =>
          `¡GOOOOOL! ${att} aguantó la embestida del central y la puso con efecto quirúrgico junto al palo.`,
        failText: () =>
          '¡Fuera por centímetros! La presión del defensor desestabilizó el remate y el balón rozó el poste exterior.',
      },
      {
        title: 'Amague Corporal Hacia Afuera para Eludir al Portero',
        description: 'Frenar en seco, amagar con el cuerpo y salir hacia la pierna inhábil para dejar al arquero en el suelo.',
        internalWeight: 0.31,
        statRequired: 'dribbling',
        isGoalIfSuccess: true,
        isGoalIfFail: true,
        successText: (att = 'Tu delantero') =>
          `¡GOLAZO ANTOLÓGICO! ${att} desparramó al arquero con un quiebre de cintura y definió a placer sin oposición.`,
        failText: () =>
          'El arquero no compró el amague, fue con los dos pies hacia adelante, robó el balón y armó la contra letal rival. ¡GOL EN CONTRA!',
      },
      {
        title: 'Toque al Costado para la Llegada desde Segunda Línea',
        description: 'Tocar de primera intención hacia atrás para habilitar el remate de frente del mediocampista.',
        internalWeight: 0.44,
        statRequired: 'passing',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡GOLAZO COLECTIVO! Pase rasante milimétrico y tu compañero definió con el arco desguarnecido.',
        failText: () =>
          'El último zaguero rival leyó la intención, interceptó el pase con la punta de la bota y mandó a reventar.',
      },
    ],
  },
  {
    zone: 'ataque',
    title: 'Tiro Libre al Borde de la Medialuna en Minuto Clave',
    scenarioText: () =>
      'Falta caliente al borde de la medialuna a 23 metros. El portero rival arma una barrera alta de cinco hombres y coloca un defensor recostado en el césped.',
    options: [
      {
        title: 'Disparo con Rosca Buscando la Escuadra Superior',
        description: 'Superar la barrera con comba y caída rápida buscando el ángulo más difícil.',
        internalWeight: 0.35,
        statRequired: 'shooting',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡GOLAZO MONUMENTAL! El balón tomó un efecto diabólico, superó la barrera y se clavó en la telaraña.',
        failText: () =>
          'El remate se elevó un dedo por encima del travesaño mientras todo el estadio gritaba el casi-gol.',
      },
      {
        title: 'Trallazo Seco con Empeine Total al Poste del Portero',
        description: 'Impacto violento a máxima potencia buscando quebrar las manos del guardameta.',
        internalWeight: 0.32,
        statRequired: 'physical',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡MISIL IMPARABLE Y GOL! Un proyectil a 115 km/h que perforó la estirada del portero rival.',
        failText: () =>
          'El bombazo impactó de lleno en la cabeza de un hombre de la barrera y salió despedido al lateral.',
      },
      {
        title: 'Pase Corto Picado por Encima de la Barrera',
        description: 'Engañar con amague de tiro y filtrar una cuchara al espacio para el desmarque del volante.',
        internalWeight: 0.40,
        statRequired: 'passing',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡JUGADA DE LABORATORIO Y GOL! El desmarque fue perfecto y el remate cruzado venció al arquero.',
        failText: () =>
          'La defensa no cayó en el engaño, dio un paso al frente y dejó en fuera de juego al receptor.',
      },
    ],
  },
  {
    zone: 'ataque',
    title: 'Contragolpe 3 contra 2 con Defensa Retrocediendo',
    scenarioText: () =>
      'Robo y salida a pura velocidad. Tres atacantes encaran a dos centrales rivales que retroceden perfilados tapando el medio con desesperación.',
    options: [
      {
        title: 'Apertura Rápida a la Banda para Centro Tenso',
        description: 'Abrir el campo a máxima velocidad y meter centro rasante para el anticipo del centrodelantero.',
        internalWeight: 0.42,
        statRequired: 'pace',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡CENTRO MORTAL Y GOL! El delantero se anticipó a su marca y desvió la trayectoria al fondo de la red.',
        failText: () =>
          'El centro fue interceptado por el central rival que barrió con todo al córner.',
      },
      {
        title: 'Pared Central Rápida a Primer Toque Entre los Defensores',
        description: 'Tocar y buscar la devolución en el punto ciego de la defensa a velocidad vertiginosa.',
        internalWeight: 0.33,
        statRequired: 'passing',
        isGoalIfSuccess: true,
        isGoalIfFail: true,
        successText: () =>
          '¡TIKI-TAKA EXPLOSIVO Y GOL! Desarmaron la defensa a un toque y el remate cruzado liquidó.',
        failText: () =>
          'El segundo toque quedó unos centímetros corto: el rival robó, metió pelotazo largo y anotó en la contra. ¡GOL DEL RIVAL!',
      },
      {
        title: 'Frenada en Seco y Remate Cruzado desde la Frontal',
        description: 'Aprovechar que los centrales retroceden y soltar un disparo antes de que salgan los volantes.',
        internalWeight: 0.36,
        statRequired: 'shooting',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡QUÉ GOLAZO! El remate besó el poste interior y entró. La recompensa a la audacia.',
        failText: () =>
          'El arquero rival voló a mano cambiada y desvió con la uña al tiro de esquina.',
      },
    ],
  },
  {
    zone: 'ataque',
    title: 'Desborde por Banda con Doble Marca en Línea de Fondo',
    scenarioText: (att = 'Tu extremo') =>
      `¡Duelo frenético en la raya! ${att} llega a la línea de fondo con el lateral y el volante de contención cerrándole el paso.`,
    options: [
      {
        title: 'Pase Atrás a la Frontal para el Tiro del Volante',
        description: 'Tirar el pase de la muerte hacia atrás buscando la llegada limpia del volante que viene de frente.',
        internalWeight: 0.40,
        statRequired: 'passing',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡PASE DE LA MUERTE Y GOL! El mediocampista le dio de primera con comba al palo opuesto. ¡Inatajable!',
        failText: () =>
          'El volante rival que bajó a tapar cortó el pase en el último suspiro con la punta del botín.',
      },
      {
        title: 'Enganche Hacia Adentro para Buscar el Perfil de Disparo',
        description: 'Amagar el centro con derecha, quebrar con la zurda hacia el área y buscar el tiro combado.',
        internalWeight: 0.34,
        statRequired: 'dribbling',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡OBRA DE ARTE Y GOL! Dejó a los dos marcadores en el camino y la clavó al segundo palo.',
        failText: () =>
          'El segundo zaguero metió el cuerpo con fuerza limpia y bloqueó el disparo.',
      },
      {
        title: 'Centro Picado al Segundo Poste al Espacio Aéreo',
        description: 'Bombear la pelota al segundo palo para el salto en ventaja del atacante más alto.',
        internalWeight: 0.38,
        statRequired: 'passing',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡CABEZAZO IMPLACABLE Y GOL! Martilló el balón contra el césped y dejó sin opciones al arquero.',
        failText: () =>
          'El balón tomó demasiada parábola y se perdió por el lateral del otro lado de la cancha.',
      },
    ],
  },
  {
    zone: 'ataque',
    title: 'Penal a Favor en el Minuto 90 bajo Presión Máxima',
    scenarioText: () =>
      'El árbitro pita penal. El estadio tiembla. El arquero rival se mueve sobre la línea de cal tocando los postes para desconcentrar.',
    options: [
      {
        title: 'Disparo Fuerte Cruzado a Media Altura',
        description: 'Asegurar con empeine interior fuerte hacia un costado con determinación.',
        internalWeight: 0.45,
        statRequired: 'shooting',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡GOOOL DE PENAL! Disparo seco e inatajable, la pelota pegó en la red interna con violencia.',
        failText: () =>
          '¡El arquero adivinó la punta y desvió con una estirada felina!',
      },
      {
        title: 'Picadita Suave al Estilo Panenka al Centro del Arco',
        description: 'Esperar a que el portero elija un lado y tocar suave por encima de su cuerpo.',
        internalWeight: 0.28,
        statRequired: 'dribbling',
        isGoalIfSuccess: true,
        isGoalIfFail: true,
        successText: () =>
          '¡QUÉ LOCURA, GOLAZO A LO PANENKA! El arquero voló a la esquina y la pelota entró flotando mansa al medio.',
        failText: () =>
          '¡PAPELÓN! El portero no se movió de la línea, esperó el balón con el pecho y salió jugando riéndose.',
      },
      {
        title: 'Cañonazo Violento al Medio del Travesaño',
        description: 'Romper la red sin titubeos con máxima potencia buscando el techo del arco.',
        internalWeight: 0.37,
        statRequired: 'physical',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡BOMBAZO Y GOL! El arquero se tiró a un lado y la pelota casi rompe la red del travesaño.',
        failText: () =>
          '¡Reventó el travesaño! El impacto sacudió el arco y el rebote salió despedido fuera del estadio.',
      },
    ],
  },

  // ===================== SITUACIONES DE DEFENSA =====================
  {
    zone: 'defensa',
    title: 'El Delantero Estrella Rival Encara en el 1 vs 1 en el Borde del Área',
    scenarioText: (att, def = 'Tu central') =>
      `¡Alarma total! El delantero rival, con regate endiablado, encara en velocidad hacia el área grande con ${def} como última barrera.`,
    options: [
      {
        title: 'Barrida a Ras de Suelo Jugándose la Vida al Balón',
        description: 'Ir con todo al piso para trabar limpio el esférico arriesgando el penal si falla el cálculo.',
        internalWeight: 0.35,
        statRequired: 'defending',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: (def = 'Tu central') =>
          `¡SALVADA MONUMENTAL! ${def} fue al piso con precisión milimétrica y le extirpó el balón sin falta.`,
        failText: () =>
          '¡El atacante enganchó hacia adentro, eludió la barrida y definió al rincón! GOL DEL RIVAL.',
      },
      {
        title: 'Temporizar de Pie Tapándole el Perfil Hábil de Disparo',
        description: 'Aguantar la posición, cerrar el remate hacia adentro y esperar el repliegue del mediocampo.',
        internalWeight: 0.44,
        statRequired: 'defending',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          'Gran temple defensivo: aguantaste de pie y obligaste al delantero a sacar un tiro incómodo y desviado.',
        failText: () =>
          'El crack rival frotó la lámpara, sacó un bombazo entre las piernas del zaguero y la clavó al ángulo. GOL RIVAL.',
      },
      {
        title: 'Falta Táctica Inmediata Fuera del Área para Frenar el Avance',
        description: 'Agarrar la camiseta o cortar abajo antes de que pise el área penal asumiendo la tarjeta.',
        internalWeight: 0.50,
        statRequired: 'physical',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          'Falta estratégica con tarjeta amarilla: cortaste una jugada que olía a gol inminente.',
        failText: () =>
          'El árbitro aplicó ley de la ventaja, el rival continuó la carrera con ventaja y definió solo. GOL RIVAL.',
      },
    ],
  },
  {
    zone: 'defensa',
    title: 'Asedio Aéreo en Córner Rival al Minuto 88',
    scenarioText: (att, def, gk = 'Tu arquero') =>
      `Tensión asfixiante: córner con comba cerrada del rival que cae con veneno directo a la olla del área chica de ${gk}.`,
    options: [
      {
        title: 'Salida Imponente del Guardameta a Despejar con los Puños',
        description: 'Hacerse cargo del área chica, saltar entre la marea de atacantes y despejar con fuerza.',
        internalWeight: 0.38,
        statRequired: 'defending',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: (gk = 'Tu arquero') =>
          `¡QUÉ PRESENCIA! ${gk} voló por los aires, metió dos puñetazos secos y mandó el balón a la mitad de la cancha.`,
        failText: () =>
          'El guardameta calculó mal en la salida aérea, chocó con su propio central y el delantero empujó el balón. GOL RIVAL.',
      },
      {
        title: 'Duelo Físico de Centrales para Despejar de Cabeza',
        description: 'Imponer el salto y la marca férrea hombre a hombre para cabecear hacia un costado.',
        internalWeight: 0.44,
        statRequired: 'physical',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          '¡CABEZAZO SALVADOR! El central se elevó como una torre y despejó hacia la banda lateral.',
        failText: () =>
          'El despeje quedó corto en la medialuna, el volante rival cazó el rebote de volea y rompió la red. GOL RIVAL.',
      },
      {
        title: 'Dar Dos Pasos al Frente Coordinados para el Fuera de Juego',
        description: 'Sincronizar la salida de la zaga en bloque para dejar en posición adelantada a los cabeceadores.',
        internalWeight: 0.32,
        statRequired: 'defending',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          '¡TRAMPA MILIMÉTRICA! El juez de línea levantó la bandera ahogando el grito del rival.',
        failText: () =>
          'Un lateral tardó en dar el paso, habilitó a tres hombres y el rival cabeceó con total impunidad. GOL RIVAL.',
      },
    ],
  },
  {
    zone: 'defensa',
    title: 'Contraataque Rival en Superioridad Numérica 4 contra 2',
    scenarioText: () =>
      'Tu equipo quedó descompensado en ataque tras un tiro de esquina y el rival lanza un contraataque fulminante.',
    options: [
      {
        title: 'Cerrar el Medio y Forzar el Pase hacia la Banda Exterior',
        description: 'Los dos zagueros se juntan en el centro para tapar el remate directo y obligar al rival a abrir.',
        internalWeight: 0.40,
        statRequired: 'defending',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          'Maniobra defensiva impecable: forzaste al rival a un ángulo cerrado y tu arquero contuvo el disparo.',
        failText: () =>
          'El delantero rival vio el hueco por arriba, metió una vaselina perfecta y anotó. ¡GOL DEL RIVAL!',
      },
      {
        title: 'Salida Agresiva del Arquero a Cortar como Líbero a 30 Metros',
        description: 'El portero sale disparado del área para barrer el pase largo antes de que llegue el extremo.',
        internalWeight: 0.30,
        statRequired: 'pace',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          '¡QUÉ LOCURA DE SALVADA! El portero barrió con el pecho a 25 metros de su arco y despejó al lateral.',
        failText: () =>
          'El atacante rival llegó primero a la pelota, se sacó al arquero con un toque y definió a arco vacío. GOL RIVAL.',
      },
      {
        title: 'Tirar la Trampa del Offside en Mitad de Cancha',
        description: 'Ambos defensores frenan en seco simultáneamente para dejar al pasador sin receptores habilitados.',
        internalWeight: 0.33,
        statRequired: 'defending',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          '¡Sincronización de reloj suizo! El juez cobró fuera de juego y se disipó el peligro.',
        failText: () =>
          'No hubo coordinación, el pase habilitó a dos hombres y definieron en soledad total. GOL RIVAL.',
      },
    ],
  },
  {
    zone: 'defensa',
    title: 'Rebote Suelto en el Punto Penal tras Tiro en el Palo',
    scenarioText: (att, def, gk = 'Tu portero') =>
      `¡Caos en el área! Un remate rival sacudió el palo y el balón quedó vivo en el punto penal con ${gk} en el suelo y dos rivales listos para empujarla.`,
    options: [
      {
        title: 'Lanzarse con el Cuerpo Entregando la Vida para Bloquear',
        description: 'El zaguero central se tira en plancha al césped para poner el pecho o la espalda ante el remate.',
        internalWeight: 0.36,
        statRequired: 'physical',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          '¡SALVADA HEROICA! El zaguero puso el pecho a quemarropa y el balón rebotó milagrosamente lejos del arco.',
        failText: () =>
          'El disparo pasó entre las piernas del defensor desesperado e infló la red. GOL RIVAL.',
      },
      {
        title: 'Reacción Felina del Arquero Levantándose en Fracción de Segundo',
        description: 'Impulsarse con los brazos desde el suelo para achicar con el cuerpo extendido.',
        internalWeight: 0.32,
        statRequired: 'defending',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          '¡ATAJADA DE OTRO PLANETA! A mano cambiada desde el piso evitó el gol cantado.',
        failText: () =>
          'No le dio el tiempo para levantarse y el atacante solo tuvo que tocarla al fondo. GOL RIVAL.',
      },
      {
        title: 'Despeje con Punterazo de Emergencia a Cualquier Parte',
        description: 'Meter la punta del botín con la fuerza que sea para mandar la pelota sobre el travesaño.',
        internalWeight: 0.42,
        statRequired: 'defending',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          'Despeje rústico pero salvador: la mandó al córner respirando aliviado.',
        failText: () =>
          'Pifia en el despeje: la pelota pegó en la canilla y se metió contra el propio arco. ¡AUTOGOL!',
      },
    ],
  },

  // ===================== SITUACIONES DE MEDIOCAMPO =====================
  {
    zone: 'mediocampo',
    title: 'Presión Alta Asfixiante Rival en la Salida de Balón Propia',
    scenarioText: () =>
      'El rival aprieta con tres delanteros en la boca de tu propia área penal cerrando todas las líneas de pase fáciles.',
    options: [
      {
        title: 'Pase Rasante Rompiendo Líneas hacia el Mediocentro',
        description: 'Buscar al pivote de espaldas entre los dos puntas rivales que vienen a morder con agresividad.',
        internalWeight: 0.35,
        statRequired: 'passing',
        isGoalIfSuccess: true,
        isGoalIfFail: true,
        successText: () =>
          '¡SALIDA DE CRACK Y GOLAZO! Rompiste la presión, tu volante giró en el círculo central y asistió para el GOL.',
        failText: () =>
          '¡Error fatal en salida! El rival anticipó el pase a 20 metros de tu arco y fusiló sin piedad. GOL EN CONTRA.',
      },
      {
        title: 'Pelotazo Largo Diagonal al Espacio Libre para los Extremos',
        description: 'Saltar la presión sin dudar con un envío largo bombeado hacia las bandas para alejar el peligro.',
        internalWeight: 0.46,
        statRequired: 'pace',
        isGoalIfSuccess: false,
        isGoalIfFail: false,
        successText: () =>
          'Envío seguro y efectivo: tu extremo ganó la carrera y trasladó el partido a terreno contrario.',
        failText: () =>
          'El pelotazo salió por el lateral, pero el riesgo inmediato en área propia fue disipado.',
      },
      {
        title: 'Giro de Cintura y Conducción Individual con el Cuerpo',
        description: 'Poner el cuerpo como escudo, girar sobre el eje del rival y salir jugando con gambeta pura.',
        internalWeight: 0.38,
        statRequired: 'dribbling',
        isGoalIfSuccess: false,
        isGoalIfFail: true,
        successText: () =>
          'Gran categoría técnica: pisó el balón, dejó pagando al marcador y salió jugando con prestancia.',
        failText: () =>
          'Dos rivales hicieron el sándwich, le quitaron la pelota al borde del área y anotaron sin arquero. GOL RIVAL.',
      },
    ],
  },
  {
    zone: 'mediocampo',
    title: 'Disputa de Balón Dividido Tras Rechace en Mitad de Cancha',
    scenarioText: () =>
      'Pelota flotante en el círculo central. Ambos equipos se lanzan con los dientes apretados a ganar la segunda jugada.',
    options: [
      {
        title: 'Trabar Fuerte con la Pierna Firme en el Suelo',
        description: 'Poner la suela con determinación para ganar la posición y abrir hacia la banda.',
        internalWeight: 0.42,
        statRequired: 'physical',
        isGoalIfSuccess: false,
        isGoalIfFail: false,
        successText: () =>
          'Ganaste la pelota dividida con garra y descargaste rápido para iniciar el ataque.',
        failText: () =>
          'El volante rival metió mejor el cuerpo y se quedó con el dominio del balón.',
      },
      {
        title: 'Control Orientado con el Pecho y Cambio de Frente Veloz',
        description: 'Amortiguar el balón y soltar un latigazo cruzado de 45 metros a la espalda del lateral contrario.',
        internalWeight: 0.34,
        statRequired: 'passing',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡VISIÓN EXTRAORDINARIA Y GOL! Un cambio de frente teledirigido que dejó a tu extremo mano a mano para anotar.',
        failText: () =>
          'El pase se fue un poco largo por el césped mojado y se perdió por la línea final.',
      },
      {
        title: 'Tocar Seguro con el Zaguero Central para Reordenar Líneas',
        description: 'No arriesgar la posesión y reiniciar la jugada con calma desde el fondo del campo.',
        internalWeight: 0.48,
        statRequired: 'passing',
        isGoalIfSuccess: false,
        isGoalIfFail: false,
        successText: () =>
          'Madurez táctica: posesión asegurada para respirar y construir el juego con paciencia.',
        failText: () =>
          'El pase hacia atrás quedó algo comprometido y forzó un despeje apresurado del portero.',
      },
    ],
  },
  {
    zone: 'mediocampo',
    title: 'Recuperación Rápida en Tres Cuartos con el Rival Desprevenido',
    scenarioText: () =>
      '¡Robo limpio en tres cuartos de cancha! La zaga rival está desordenada intentando volver a sus puestos.',
    options: [
      {
        title: 'Pase Filtrado al Vacío Entre los Dos Centrales',
        description: 'Meter un pase rasante con efecto que corte la línea defensiva para la carrera del 9.',
        internalWeight: 0.36,
        statRequired: 'passing',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡ASISTENCIA DE ORO Y GOL! Pase milimétrico que dejó a tu goleador solo frente al arco para definir.',
        failText: () =>
          'El central rival metió la pierna con lo justo y desvió el pase.',
      },
      {
        title: 'Remate Sorpresivo desde 30 Metros Viendo al Arquero Adelantado',
        description: 'Aprovechar que el guardameta está dos pasos fuera de su arco y soltar un derechazo por arriba.',
        internalWeight: 0.29,
        statRequired: 'shooting',
        isGoalIfSuccess: true,
        isGoalIfFail: false,
        successText: () =>
          '¡QUÉ LOCURA DE GOL! La pelota cayó como un meteorito por encima del portero estupefacto.',
        failText: () =>
          'El disparo se fue alto por encima del travesaño mientras los compañeros reclamaban el pase.',
      },
      {
        title: 'Conducir Hacia la Banda para Congelar el Ritmo y Asegurar',
        description: 'Mantener la posesión, esperar que el equipo suba y no arriesgar la pelota ganada.',
        internalWeight: 0.46,
        statRequired: 'dribbling',
        isGoalIfSuccess: false,
        isGoalIfFail: false,
        successText: () =>
          'Buena lectura del momento: aseguraste el dominio y enfriaste la reacción del rival.',
        failText: () =>
          'La pausa fue excesiva, tres rivales rodearon al volante y le cometieron falta táctica.',
      },
    ],
  },
];

// Generates EXACTLY 5 situations per match across 90 minutes with high difficulty
export function generate5MatchSituations(userTeam: {
  delantero?: Player;
  mediocampista?: Player;
  defensa?: Player;
  portero?: Player;
}): MatchSituation[] {
  // Exactly 5 key minutes: 18', 36', 54', 72', 88'
  const minutes = [18, 36, 54, 72, 88];

  const shuffledTemplates = [...TEMPLATES_POOL].sort(() => 0.5 - Math.random());
  const selectedTemplates = shuffledTemplates.slice(0, 5);

  const attackerName = userTeam.delantero?.shortName || 'Tu Delantero';
  const defenderName = userTeam.defensa?.shortName || 'Tu Central';
  const gkName = userTeam.portero?.shortName || 'Tu Portero';

  return minutes.map((minute, idx) => {
    const tmpl = selectedTemplates[idx] || TEMPLATES_POOL[idx % TEMPLATES_POOL.length];

    // Shuffle the 3 options so the outcome is never predictable by position
    const shuffledOpts = [...tmpl.options].sort(() => 0.5 - Math.random());

    const mappedOptions = shuffledOpts.map((opt, optIdx) => ({
      id: `opt_${idx}_${optIdx}`,
      title: opt.title,
      description: opt.description,
      internalRiskWeight: opt.internalWeight,
      statRequired: opt.statRequired,
      outcomeSuccess: {
        text: opt.successText(attackerName),
        pointsGoal: opt.isGoalIfSuccess ? 1 : 0,
        flavor: 'Acierto táctico',
      },
      outcomeFail: {
        text: opt.failText(attackerName),
        pointsConceded: opt.isGoalIfFail ? 1 : 0,
        flavor: 'Fallo en la jugada',
      },
    })) as [SituationOption, SituationOption, SituationOption];

    return {
      id: `sit_${idx}_${minute}`,
      minute,
      zone: tmpl.zone,
      title: tmpl.title,
      scenarioText: tmpl.scenarioText(attackerName, defenderName, gkName),
      playerInvolved: tmpl.zone === 'ataque' ? attackerName : tmpl.zone === 'defensa' ? defenderName : undefined,
      options: mappedOptions,
    };
  });
}
