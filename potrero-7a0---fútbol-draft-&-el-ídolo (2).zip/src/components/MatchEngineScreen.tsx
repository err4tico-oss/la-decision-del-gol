import { useState } from 'react';
import { MatchSituation, SituationOption, TournamentTeam, Player, MatchStageInfo } from '../types/game';
import { generate5MatchSituations } from '../data/matchSituations';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';
import { CheckCircle2, XCircle, ArrowRight } from 'lucide-react';

interface MatchEngineScreenProps {
  userTeamOvr: number;
  userSquad: {
    delantero?: Player;
    mediocampista?: Player;
    defensa?: Player;
    portero?: Player;
  };
  rivalTeam: TournamentTeam;
  stageInfo: MatchStageInfo;
  onMatchComplete: (result: { userScore: number; rivalScore: number; won: boolean; isDraw?: boolean }) => void;
}

export function MatchEngineScreen({
  userTeamOvr,
  userSquad,
  rivalTeam,
  stageInfo,
  onMatchComplete,
}: MatchEngineScreenProps) {
  // Generate the 5 match situations (harder difficulty)
  const [situations] = useState<MatchSituation[]>(() => {
    return generate5MatchSituations(userSquad);
  });

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [userScore, setUserScore] = useState<number>(0);
  const [rivalScore, setRivalScore] = useState<number>(0);

  // Outcome resolution state for active situation
  const [resolving, setResolving] = useState<boolean>(false);
  const [outcome, setOutcome] = useState<{
    success: boolean;
    text: string;
    pointsGoal: number;
    pointsConceded: number;
    optionTitle: string;
  } | null>(null);

  // Log history of played situations
  const [history, setHistory] = useState<{
    minute: number;
    zone: string;
    title: string;
    chosenTitle: string;
    success: boolean;
    text: string;
    userScore: number;
    rivalScore: number;
  }[]>([]);

  // Penalty shootout state if tied in knockout match
  const [isShootout, setIsShootout] = useState<boolean>(false);
  const [userPenalties, setUserPenalties] = useState<number>(0);
  const [rivalPenalties, setRivalPenalties] = useState<number>(0);
  const [penaltiesRound, setPenaltiesRound] = useState<number>(0);
  const [penaltyFeedback, setPenaltyFeedback] = useState<string>('');

  const currentSituation = situations[currentIndex];
  const isMatchFinished = currentIndex >= 5 && !isShootout;

  // Execute tactical choice with tight difficulty balance
  const handleSelectOption = (opt: SituationOption) => {
    if (resolving || outcome) return;
    setResolving(true);
    sound.playCardPick();

    setTimeout(() => {
      // Player attribute factor
      let statValue = 72;
      if (opt.statRequired === 'shooting' && userSquad.delantero) statValue = userSquad.delantero.shooting;
      else if (opt.statRequired === 'dribbling' && userSquad.delantero) statValue = userSquad.delantero.dribbling;
      else if (opt.statRequired === 'pace' && userSquad.delantero) statValue = userSquad.delantero.pace;
      else if (opt.statRequired === 'passing' && userSquad.mediocampista) statValue = userSquad.mediocampista.passing;
      else if (opt.statRequired === 'defending' && userSquad.defensa) statValue = userSquad.defensa.defending;
      else if (opt.statRequired === 'physical' && userSquad.defensa) statValue = userSquad.defensa.physical;

      // Realistic and demanding difficulty calculation:
      // OVR delta plays a critical role against elite champions and national teams
      const ovrDelta = userTeamOvr - rivalTeam.ovr;
      const statBonus = (statValue - 78) * 0.005;
      const ovrModifier = ovrDelta * 0.008;

      // Challenging clamp between 12% and 65% max so victories are hard-earned
      const finalRate = Math.min(0.65, Math.max(0.12, opt.internalRiskWeight + statBonus + ovrModifier));
      const roll = Math.random();
      const isSuccess = roll < finalRate;

      let newU = userScore;
      let newR = rivalScore;

      if (isSuccess) {
        if (opt.outcomeSuccess.pointsGoal > 0) {
          newU += 1;
          setUserScore(newU);
          sound.playGoalRoar();
          confetti({ particleCount: 50, spread: 60 });
        } else {
          sound.playWhistle();
        }
      } else {
        if (opt.outcomeFail.pointsConceded > 0) {
          newR += 1;
          setRivalScore(newR);
          sound.playFail();
        } else {
          // If rival has strong OVR (>= 82) and you fail, 42% chance they counter-attack and score!
          if (rivalTeam.ovr >= 82 && Math.random() < 0.42) {
            newR += 1;
            setRivalScore(newR);
            sound.playFail();
          } else {
            sound.playPostHit();
          }
        }
      }

      const outcomeData = {
        success: isSuccess,
        text: isSuccess ? opt.outcomeSuccess.text : opt.outcomeFail.text,
        pointsGoal: isSuccess ? opt.outcomeSuccess.pointsGoal : 0,
        pointsConceded: !isSuccess ? opt.outcomeFail.pointsConceded : 0,
        optionTitle: opt.title,
      };

      setOutcome(outcomeData);
      setResolving(false);

      setHistory((prev) => [
        ...prev,
        {
          minute: currentSituation.minute,
          zone: currentSituation.zone,
          title: currentSituation.title,
          chosenTitle: opt.title,
          success: isSuccess,
          text: outcomeData.text,
          userScore: newU,
          rivalScore: newR,
        },
      ]);
    }, 550);
  };

  // Move to next situation or handle match completion
  const handleNextSituation = () => {
    setOutcome(null);
    const nextIdx = currentIndex + 1;
    setCurrentIndex(nextIdx);

    if (nextIdx >= 5) {
      // If knockout match and score is tied, trigger sudden death penalties
      if (stageInfo.isKnockout && userScore === rivalScore) {
        setIsShootout(true);
        sound.playWhistle();
        setPenaltyFeedback('¡EMPATE AL FINAL DE LAS 5 JUGADAS! Definición por penales.');
      }
    }
  };

  // Penalty shootout for knockout matches
  const handleShootPenalty = (direction: 'izq' | 'centro' | 'der') => {
    sound.playKick();
    const gkGuess = ['izq', 'centro', 'der'][Math.floor(Math.random() * 3)];
    const userScored = direction !== gkGuess;

    const rivalDirection = ['izq', 'centro', 'der'][Math.floor(Math.random() * 3)];
    const userGkGuess = ['izq', 'centro', 'der'][Math.floor(Math.random() * 3)];
    const rivalScored = rivalDirection !== userGkGuess;

    const nextUserP = userPenalties + (userScored ? 1 : 0);
    const nextRivalP = rivalPenalties + (rivalScored ? 1 : 0);
    const nextRound = penaltiesRound + 1;

    setUserPenalties(nextUserP);
    setRivalPenalties(nextRivalP);
    setPenaltiesRound(nextRound);

    if (userScored && !rivalScored) {
      sound.playGoalRoar();
      confetti({ particleCount: 120, spread: 80 });
      setPenaltyFeedback('¡¡¡GOLAZO Y ATAJADA DECISIVA DEL PORTERO!!! ¡GANASTE LA TANDA!');
      setTimeout(() => {
        setIsShootout(false);
        onMatchComplete({
          userScore: userScore + 1,
          rivalScore,
          won: true,
        });
      }, 1600);
    } else if (!userScored && rivalScored) {
      sound.playFail();
      setPenaltyFeedback('¡Fallaste tu penal y el rival anotó! Eliminado en los penales.');
      setTimeout(() => {
        setIsShootout(false);
        onMatchComplete({
          userScore,
          rivalScore: rivalScore + 1,
          won: false,
        });
      }, 1600);
    } else {
      if (userScored) sound.playGoalRoar();
      else sound.playPostHit();
      setPenaltyFeedback(
        `Ronda ${nextRound}: ${userScored ? 'Gol' : 'Fallado'} · Rival: ${rivalScored ? 'Gol' : 'Atajado'}. Marcador Penales: ${nextUserP}-${nextRivalP}. Sigue la muerte súbita.`
      );
    }
  };

  // Finish match callback
  const handleFinishMatch = () => {
    const won = userScore > rivalScore;
    const isDraw = userScore === rivalScore && !stageInfo.isKnockout;
    onMatchComplete({
      userScore,
      rivalScore,
      won,
      isDraw,
    });
  };

  const zoneBadgeStyle = {
    ataque: 'text-amber-400 bg-amber-950/60 border-amber-500/40',
    defensa: 'text-sky-400 bg-sky-950/60 border-sky-500/40',
    mediocampo: 'text-emerald-400 bg-emerald-950/60 border-emerald-500/40',
  }[currentSituation?.zone || 'ataque'];

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 pb-12">
      {/* Top Match Scoreboard Header */}
      <div className="bg-gradient-to-r from-slate-950 via-[#101a14] to-slate-950 border-2 border-amber-500/40 rounded-3xl p-5 sm:p-7 shadow-2xl">
        <div className="flex items-center justify-between text-xs font-bold text-amber-400 uppercase tracking-widest mb-3 border-b border-slate-800 pb-2">
          <span>{stageInfo.phaseName}</span>
          <span>Partido {stageInfo.matchNumber} de {stageInfo.totalMatches}</span>
        </div>

        <div className="grid grid-cols-3 items-center text-center">
          {/* User Team */}
          <div className="text-left sm:text-center">
            <span className="text-[11px] font-bold text-slate-400 block uppercase">Tu Plantilla FUT</span>
            <h3 className="font-heading text-2xl sm:text-4xl font-extrabold text-amber-400 uppercase leading-none truncate">
              Mi Equipo
            </h3>
            <span className="text-xs text-slate-400 font-semibold">OVR {userTeamOvr}</span>
          </div>

          {/* Score & Minute */}
          <div className="flex flex-col items-center">
            <span className="font-mono text-xs font-bold px-3 py-1 bg-black/60 rounded-full border border-amber-500/30 text-amber-300 tabular-nums animate-pulse">
              {currentIndex < 5 ? `${currentSituation.minute}' Minuto` : 'Tiempo Cumplido'}
            </span>
            <div className="font-heading text-5xl sm:text-7xl font-black text-slate-100 tracking-tight tabular-nums mt-1">
              {userScore} - {rivalScore}
            </div>
            <span className="text-[11px] font-bold text-slate-400 mt-1 uppercase">
              {currentIndex < 5 ? `Situación ${currentIndex + 1} de 5` : '5 Situaciones Completadas'}
            </span>
          </div>

          {/* Rival Team */}
          <div className="text-right sm:text-center">
            <span className="text-[11px] font-bold text-slate-400 block uppercase">Rival Sorteado</span>
            <div className="flex items-center justify-end sm:justify-center gap-1.5">
              <span className="text-xl sm:text-2xl">{rivalTeam.logoEmoji}</span>
              <h3 className="font-heading text-2xl sm:text-4xl font-extrabold text-slate-100 uppercase leading-none truncate">
                {rivalTeam.name}
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-semibold">OVR {rivalTeam.ovr}</span>
          </div>
        </div>
      </div>

      {/* ACTIVE SITUATION CARD */}
      {currentIndex < 5 && !isShootout && (
        <div className="bg-[#0e1611] border border-amber-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          {/* Situation Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <span className={`text-xs font-black uppercase px-3 py-1 rounded-lg border ${zoneBadgeStyle}`}>
                {currentSituation.zone}
              </span>
              <span className="text-xs text-slate-400 font-bold">
                Minuto {currentSituation.minute}'
              </span>
            </div>

            <span className="text-xs font-bold text-amber-400">
              Situación {currentIndex + 1} de 5
            </span>
          </div>

          {/* Scenario Narrative */}
          <div className="space-y-2">
            <h3 className="font-heading text-3xl sm:text-4xl font-extrabold text-slate-100 tracking-tight uppercase">
              {currentSituation.title}
            </h3>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed bg-black/40 p-4 rounded-2xl border border-slate-800">
              {currentSituation.scenarioText}
            </p>
          </div>

          {/* The 3 Tactical Choices: WITHOUT ANY RISK LABELS */}
          {!outcome ? (
            <div className="space-y-3">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
                ¿Qué decisión tomas en esta jugada?
              </span>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {currentSituation.options.map((opt, idx) => (
                  <button
                    key={opt.id}
                    onClick={() => handleSelectOption(opt)}
                    disabled={resolving}
                    className="p-5 rounded-2xl bg-slate-900/90 hover:bg-amber-500 hover:text-black border border-slate-800 hover:border-amber-400 text-left transition-all cursor-pointer group flex flex-col justify-between"
                  >
                    <div>
                      <span className="text-xs font-bold text-amber-400 group-hover:text-black block mb-2">
                        Opción {idx + 1}
                      </span>
                      <h4 className="font-bold text-base text-slate-100 group-hover:text-black leading-snug mb-2">
                        {opt.title}
                      </h4>
                      <p className="text-xs text-slate-400 group-hover:text-black/90 leading-relaxed">
                        {opt.description}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800 group-hover:border-black/20 flex items-center justify-end text-slate-400 group-hover:text-black">
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Outcome Reveal Card */
            <div className="space-y-4 animate-in fade-in zoom-in-95 duration-200">
              <div
                className={`p-5 rounded-2xl border-2 flex items-start gap-4 ${
                  outcome.success
                    ? 'bg-emerald-950/50 border-emerald-500 text-emerald-200'
                    : 'bg-red-950/50 border-red-500 text-red-200'
                }`}
              >
                {outcome.success ? (
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-8 h-8 text-red-400 shrink-0 mt-0.5" />
                )}

                <div className="space-y-1">
                  <span className="text-xs font-bold uppercase tracking-wider block">
                    {outcome.success ? '¡Jugada Exitosa!' : '¡Jugada Frustrada!'} · Decisión: {outcome.optionTitle}
                  </span>
                  <p className="text-sm font-bold text-white leading-relaxed">
                    {outcome.text}
                  </p>
                  {outcome.pointsGoal > 0 && (
                    <span className="inline-block mt-2 font-heading text-2xl font-black text-amber-300">
                      ★ ¡GOL DE TU EQUIPO! (+1)
                    </span>
                  )}
                  {outcome.pointsConceded > 0 && (
                    <span className="inline-block mt-2 font-heading text-2xl font-black text-rose-300">
                      ★ GOL DEL RIVAL (+1)
                    </span>
                  )}
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={handleNextSituation}
                  className="py-3 px-8 bg-amber-500 hover:bg-amber-400 text-black font-heading text-2xl font-bold uppercase tracking-wider rounded-xl shadow-xl transition-all cursor-pointer flex items-center gap-2"
                >
                  <span>{currentIndex < 4 ? 'Siguiente Situación' : 'Ver Resultado Final'}</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUDDEN DEATH PENALTY SHOOTOUT (Knockout tie) */}
      {isShootout && (
        <div className="bg-[#121c16] border-2 border-amber-400 rounded-3xl p-6 sm:p-8 space-y-6 text-center animate-in zoom-in-95">
          <div className="space-y-1">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block">
              Eliminatoria · Muerte Súbita
            </span>
            <h3 className="font-heading text-4xl sm:text-5xl font-black text-slate-100 uppercase">
              Tanda de Penales Decisiva
            </h3>
            <p className="text-xs sm:text-sm text-slate-300">
              {penaltyFeedback || 'Elige dónde ejecutar tu penal para superar al portero rival.'}
            </p>
          </div>

          <div className="font-heading text-4xl font-black text-amber-400 tabular-nums">
            Tus Penales: {userPenalties} · Rival: {rivalPenalties}
          </div>

          <div className="grid grid-cols-3 gap-3 max-w-md mx-auto pt-2">
            <button
              onClick={() => handleShootPenalty('izq')}
              className="py-4 bg-slate-900 hover:bg-amber-500 hover:text-black border border-amber-500/40 rounded-2xl font-heading text-2xl font-bold uppercase cursor-pointer transition-colors"
            >
              Palo Izquierdo
            </button>
            <button
              onClick={() => handleShootPenalty('centro')}
              className="py-4 bg-slate-900 hover:bg-amber-500 hover:text-black border border-amber-500/40 rounded-2xl font-heading text-2xl font-bold uppercase cursor-pointer transition-colors"
            >
              Al Centro (Fuerte)
            </button>
            <button
              onClick={() => handleShootPenalty('der')}
              className="py-4 bg-slate-900 hover:bg-amber-500 hover:text-black border border-amber-500/40 rounded-2xl font-heading text-2xl font-bold uppercase cursor-pointer transition-colors"
            >
              Palo Derecho
            </button>
          </div>
        </div>
      )}

      {/* MATCH FINISHED SUMMARY */}
      {isMatchFinished && (
        <div className="bg-gradient-to-b from-[#101b14] to-slate-950 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-10 text-center space-y-6 shadow-2xl">
          <div className="space-y-2">
            <h3 className="font-heading text-5xl sm:text-6xl font-black text-slate-100 uppercase tracking-tight">
              {userScore > rivalScore
                ? '¡VICTORIA DEL PARTIDO!'
                : userScore === rivalScore && !stageInfo.isKnockout
                ? '¡EMPATE REPARTIDO!'
                : 'DERROTA DEL EQUIPO'}
            </h3>
            <p className="text-sm text-slate-300">
              Resultado final: <strong className="text-amber-400 tabular-nums">{userScore} - {rivalScore}</strong> ante {rivalTeam.name}.
            </p>
          </div>

          {/* History of 5 choices */}
          <div className="space-y-2 max-h-56 overflow-y-auto text-left border border-slate-800 rounded-2xl p-4 bg-black/40 text-xs">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Resumen de tus 5 decisiones:
            </span>
            {history.map((h, i) => (
              <div
                key={i}
                className={`p-2.5 rounded-xl border flex items-center justify-between gap-3 ${
                  h.success
                    ? 'border-emerald-500/30 bg-emerald-950/20 text-emerald-200'
                    : 'border-red-500/30 bg-red-950/20 text-red-200'
                }`}
              >
                <span className="font-mono font-bold text-amber-400 tabular-nums">{h.minute}'</span>
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-slate-100 truncate">{h.title}</p>
                  <p className="text-[11px] opacity-80 truncate">Decisión: {h.chosenTitle}</p>
                </div>
                <span className="font-bold shrink-0">
                  {h.success ? '✓ Acierto' : '✗ Fallo'}
                </span>
              </div>
            ))}
          </div>

          <button
            onClick={handleFinishMatch}
            className="py-4 px-10 bg-amber-500 hover:bg-amber-400 text-black font-heading text-2xl font-bold uppercase tracking-wider rounded-2xl shadow-xl transition-all cursor-pointer"
          >
            {userScore >= rivalScore || !stageInfo.isKnockout
              ? 'Continuar al Sorteo del Próximo Rival'
              : 'Ver Desenlace de Eliminación'}
          </button>
        </div>
      )}
    </div>
  );
}
