import { useState } from 'react';
import { Volume2, VolumeX, Shield } from 'lucide-react';
import { sound } from '../utils/audio';

interface HeaderProps {
  currentStage: 'draft' | 'tournament_select' | 'bracket' | 'match' | 'trophy';
  teamOvr: number;
  onReset: () => void;
}

export function Header({ currentStage, teamOvr, onReset }: HeaderProps) {
  const [muted, setMuted] = useState(sound.getMuted());

  const handleToggleSound = () => {
    const isMuted = sound.toggleMute();
    setMuted(isMuted);
    if (!isMuted) {
      sound.playWhistle();
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#080d0a]/95 backdrop-blur-md border-b border-amber-500/20 px-4 md:px-8 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Brand wordmark */}
        <button
          onClick={onReset}
          className="text-left group cursor-pointer focus:outline-none flex items-center gap-2"
        >
          <span className="font-heading text-3xl md:text-4xl font-extrabold tracking-wider text-amber-400 group-hover:text-amber-300 transition-colors uppercase">
            LA DECISIÓN DEL GOL
          </span>
        </button>

        {/* Zone 2: Navigation Steps */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-bold tracking-wide">
          <span
            className={`${
              currentStage === 'draft' ? 'text-amber-400 underline underline-offset-8 decoration-2' : 'text-slate-400'
            }`}
          >
            1. Draft de 11 Titulares
          </span>
          <span
            className={`${
              currentStage === 'tournament_select'
                ? 'text-amber-400 underline underline-offset-8 decoration-2'
                : 'text-slate-400'
            }`}
          >
            2. Champions o Mundial
          </span>
          <span
            className={`${
              currentStage === 'bracket' || currentStage === 'match'
                ? 'text-amber-400 underline underline-offset-8 decoration-2'
                : 'text-slate-400'
            }`}
          >
            3. Partidos (5 Decisiones Clave)
          </span>
        </nav>

        {/* Zone 3: Actions & OVR badge */}
        <div className="flex items-center gap-3">
          {teamOvr > 0 && (
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 bg-amber-950/60 border border-amber-500/40 px-3 py-1.5 rounded-lg tabular-nums">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span>Plantilla: {teamOvr} OVR</span>
            </div>
          )}

          <button
            onClick={handleToggleSound}
            aria-label={muted ? 'Activar sonido' : 'Silenciar sonido'}
            className="p-2 text-slate-300 hover:text-amber-400 bg-slate-900 border border-slate-700 hover:border-amber-500/50 rounded-lg transition-colors cursor-pointer"
            title={muted ? 'Activar sonido' : 'Silenciar sonido'}
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
}
