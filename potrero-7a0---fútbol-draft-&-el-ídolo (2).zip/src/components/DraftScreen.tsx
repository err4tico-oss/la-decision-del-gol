import { useState, useMemo, useEffect, useCallback } from 'react';
import { Player, PositionCode, TacticalFormation } from '../types/game';
import { TACTICAL_FORMATIONS, DEFAULT_FORMATION } from '../data/formations';
import { PLAYERS_DB, PLAYER_COUNTS } from '../data/players';
import { FutCard } from './FutCard';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  RefreshCw,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  Dices,
  LayoutGrid,
  Info,
  AlertTriangle,
} from 'lucide-react';

interface DraftScreenProps {
  onDraftComplete: (team: {
    lineup: Record<PositionCode, Player | null>;
    ovr: number;
    formationId: string;
  }) => void;
}

export function DraftScreen({ onDraftComplete }: DraftScreenProps) {
  // Selected tactical formation (player can choose whichever they want)
  const [selectedFormationId, setSelectedFormationId] = useState<string>('4-3-3');

  const currentFormation = useMemo<TacticalFormation>(() => {
    return TACTICAL_FORMATIONS.find((f) => f.id === selectedFormationId) || DEFAULT_FORMATION;
  }, [selectedFormationId]);

  // Lineup state with dynamic slots based on selected formation
  const [lineup, setLineup] = useState<Record<string, Player | null>>(() => {
    const initial: Record<string, Player | null> = {};
    DEFAULT_FORMATION.slots.forEach((s) => {
      initial[s.code] = null;
    });
    return initial;
  });

  // EXACTLY 3 CARD CHANGES MAXIMUM ALLOWED IN THE ENTIRE GAME
  const [rerollsLeft, setRerollsLeft] = useState<number>(3);

  // Active slot currently being drafted
  const [activeSlotCode, setActiveSlotCode] = useState<string | null>(() => DEFAULT_FORMATION.slots[0].code);
  const [shuffleCounter, setShuffleCounter] = useState<number>(0);

  // Active slot details
  const activeSlot = useMemo(() => {
    return currentFormation.slots.find((s) => s.code === activeSlotCode);
  }, [currentFormation, activeSlotCode]);

  // When changing formation, re-initialize lineup slots
  const handleSelectFormation = (formationId: string) => {
    if (formationId === selectedFormationId) return;

    const newFormation = TACTICAL_FORMATIONS.find((f) => f.id === formationId) || DEFAULT_FORMATION;
    sound.playCardPick();
    setSelectedFormationId(formationId);

    const newLineup: Record<string, Player | null> = {};
    newFormation.slots.forEach((s) => {
      newLineup[s.code] = null;
    });
    setLineup(newLineup);
    setActiveSlotCode(newFormation.slots[0].code);
    setShuffleCounter((c) => c + 1);
  };

  // Generate 5 truly random options without repetition across already drafted players
  // INFLUENCED DIRECTLY BY THE CHOSEN FORMATION AND SPECIFIC TACTICAL ROLE
  const generate5Cards = useCallback((): Player[] => {
    if (!activeSlot) return [];

    const alreadyPickedIds = new Set(
      Object.values(lineup)
        .filter((p): p is Player => p !== null)
        .map((p) => p.id)
    );

    const categoryCandidates = PLAYERS_DB.filter(
      (p) => p.category === activeSlot.category && !alreadyPickedIds.has(p.id)
    );

    if (categoryCandidates.length <= 5) return categoryCandidates;

    // Tactical formation influence: prioritize players whose exact sub-position matches the slot
    let candidates = categoryCandidates;
    if (activeSlot.preferredSubPosition) {
      const exactSub = categoryCandidates.filter((p) => p.position === activeSlot.preferredSubPosition);
      const otherSub = categoryCandidates.filter((p) => p.position !== activeSlot.preferredSubPosition);

      // If we have enough players matching this tactical sub-role, make 75% of candidate pool from that exact role
      if (exactSub.length >= 8) {
        const shufExact = [...exactSub].sort(() => 0.5 - Math.random());
        const shufOther = [...otherSub].sort(() => 0.5 - Math.random());
        candidates = [...shufExact.slice(0, 32), ...shufOther.slice(0, 10)];
      }
    }

    // Categorize by tiers
    const icons = candidates.filter((p) => p.tier === 'icon');
    const elite = candidates.filter((p) => p.ovr >= 86 && p.tier !== 'icon');
    const gold = candidates.filter((p) => p.ovr >= 80 && p.ovr < 86 && p.tier !== 'icon');
    const silver = candidates.filter((p) => p.ovr >= 75 && p.ovr < 80 && p.tier !== 'icon');
    const bronze = candidates.filter((p) => p.ovr < 75 && p.tier !== 'icon');

    const shuffle = <T,>(arr: T[]): T[] => [...arr].sort(() => 0.5 - Math.random());

    const result: Player[] = [];

    // 1. ÍCONO / LEYENDA (~6.5% de probabilidad: difícil de conseguir pero alcanzable)
    if (Math.random() < 0.065 && icons.length > 0) {
      result.push(shuffle(icons)[0]);
    }

    // 2. ORO ÉLITE (86+ OVR): ~22% de probabilidad
    if (Math.random() < 0.22 && elite.length > 0) {
      const shufElite = shuffle(elite.filter((e) => !result.some((r) => r.id === e.id)));
      if (shufElite.length > 0) result.push(shufElite[0]);
    }

    // 3. ORO REGULAR (80 - 85 OVR): 1 a 2 cartas
    const shufGold = shuffle(gold.filter((g) => !result.some((r) => r.id === g.id)));
    if (shufGold.length > 0) result.push(shufGold[0]);
    if (shufGold.length > 1 && Math.random() < 0.45) result.push(shufGold[1]);

    // 4. PLATA (75 - 79 OVR): 1 a 2 cartas
    const shufSilver = shuffle(silver.filter((s) => !result.some((r) => r.id === s.id)));
    if (shufSilver.length > 0) result.push(shufSilver[0]);
    if (shufSilver.length > 1 && Math.random() < 0.6) result.push(shufSilver[1]);

    // 5. BRONCE / FANGO (65 - 74 OVR): 1 carta para garantizar dificultad y variedad
    const shufBronze = shuffle(bronze.filter((b) => !result.some((r) => r.id === b.id)));
    if (shufBronze.length > 0 && result.length < 5) result.push(shufBronze[0]);

    // Fill remaining up to 5 from total pool without duplicates
    const remaining = shuffle(candidates.filter((c) => !result.some((r) => r.id === c.id)));
    while (result.length < 5 && remaining.length > 0) {
      result.push(remaining.pop()!);
    }

    return shuffle(result.slice(0, 5));
  }, [activeSlot, lineup]);

  // Current 5 options state
  const [current5Options, setCurrent5Options] = useState<Player[]>([]);

  useEffect(() => {
    if (activeSlotCode) {
      setCurrent5Options(generate5Cards());
    } else {
      setCurrent5Options([]);
    }
  }, [activeSlotCode, shuffleCounter, generate5Cards]);

  // Handle re-rolling current 5 cards (COSTS 1 CHANGE OUT OF 3 MAXIMUM)
  const handleManualReroll = () => {
    if (rerollsLeft <= 0) {
      sound.playFail();
      return;
    }
    sound.playCardPick();
    setRerollsLeft((r) => r - 1);
    setShuffleCounter((c) => c + 1);
  };

  // Handle replacing an already drafted player (COSTS 1 CHANGE OUT OF 3 MAXIMUM)
  const handleReplaceDraftedPlayer = (slotCode: string) => {
    if (rerollsLeft <= 0) {
      sound.playFail();
      return;
    }
    sound.playCardPick();
    setRerollsLeft((r) => r - 1);
    setLineup((prev) => ({
      ...prev,
      [slotCode]: null,
    }));
    setActiveSlotCode(slotCode);
    setShuffleCounter((c) => c + 1);
  };

  // Count filled slots
  const filledSlotsCount = useMemo(() => {
    return Object.values(lineup).filter((p): p is Player => p !== null).length;
  }, [lineup]);

  // Overall Team Rating (OVR)
  const teamOvr = useMemo(() => {
    const players = Object.values(lineup).filter((p): p is Player => p !== null);
    if (players.length === 0) return 0;
    const sum = players.reduce((acc, p) => acc + p.ovr, 0);
    return Math.round(sum / players.length);
  }, [lineup]);

  // Handle picking one of the 5 cards
  const handleSelectPlayer = (player: Player) => {
    if (!activeSlotCode) return;
    sound.playCardPick();

    const updatedLineup: Record<string, Player | null> = {
      ...lineup,
      [activeSlotCode]: player,
    };
    setLineup(updatedLineup);

    // Find next unfilled slot in the selected formation
    const nextSlot = currentFormation.slots.find((s) => updatedLineup[s.code] === null)?.code || null;

    if (nextSlot) {
      setActiveSlotCode(nextSlot);
      setShuffleCounter((c) => c + 1);
    } else {
      setActiveSlotCode(null);
      confetti({ particleCount: 100, spread: 80 });
      sound.playGoalRoar();
    }
  };

  // Reset entire draft
  const handleResetDraft = () => {
    sound.playWhistle();
    const empty: Record<string, Player | null> = {};
    currentFormation.slots.forEach((s) => {
      empty[s.code] = null;
    });
    setLineup(empty);
    setRerollsLeft(3); // Reset the 3 changes
    setActiveSlotCode(currentFormation.slots[0].code);
    setShuffleCounter((c) => c + 1);
  };

  const isComplete = filledSlotsCount === 11;

  const handleProceedToTournament = () => {
    sound.playWhistle();
    onDraftComplete({
      lineup,
      ovr: teamOvr,
      formationId: selectedFormationId,
    });
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6 pb-12">
      {/* Header Info Bar */}
      <div className="bg-slate-900/95 border border-amber-500/30 rounded-2xl p-4 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block mb-1">
            La Decisión del Gol · FUT Draft Táctico
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-slate-100 uppercase tracking-tight leading-none">
            Elige tu Formación & Arma tu Once
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            La formación que elijas <strong>influye directamente en las posiciones y tipos de jugadores que aparecen</strong> en el draft.
            Solo tienes <strong>3 cambios de carta en toda la partida</strong>.
          </p>
        </div>

        <div className="flex items-center gap-4">
          {/* 3 CHANGES COUNTER BADGE */}
          <div className="bg-black/70 border border-amber-500/50 rounded-2xl px-4 py-2.5 text-center shadow-lg">
            <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider mb-1">
              Cambios de Carta
            </span>
            <div className="flex items-center justify-center gap-1.5 mb-1">
              {[1, 2, 3].map((num) => (
                <span
                  key={num}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    num <= rerollsLeft
                      ? 'bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.9)] ring-1 ring-amber-300'
                      : 'bg-slate-800 border border-slate-700 opacity-40'
                  }`}
                  title={num <= rerollsLeft ? 'Cambio disponible' : 'Cambio consumido'}
                />
              ))}
            </div>
            <span className={`text-xs font-black font-mono ${rerollsLeft > 0 ? 'text-amber-400' : 'text-rose-400'}`}>
              {rerollsLeft} / 3 Restantes
            </span>
          </div>

          <div className="text-right">
            <span className="text-[11px] font-bold text-slate-400 block uppercase">Media de Equipo</span>
            <span className="font-heading text-4xl sm:text-5xl font-black text-amber-400 tabular-nums leading-none">
              {teamOvr || '--'}
            </span>
          </div>

          <div className="border-l border-slate-700 pl-4 text-right">
            <span className="text-[11px] font-bold text-slate-400 block uppercase">Completado</span>
            <span className="font-heading text-3xl sm:text-4xl font-black text-slate-200 tabular-nums leading-none">
              {filledSlotsCount} / 11
            </span>
          </div>

          <button
            onClick={handleResetDraft}
            title="Reiniciar todo el Draft y restaurar 3 cambios"
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-400 rounded-xl cursor-pointer transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* FORMATION SELECTOR BAR */}
      <div className="bg-[#0b120e] border border-amber-500/20 rounded-2xl p-4 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <LayoutGrid className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              1. Selecciona tu Formación Táctica:
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            {currentFormation.tagline}
          </span>
        </div>

        {/* Formation Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
          {TACTICAL_FORMATIONS.map((form) => {
            const isSelected = form.id === selectedFormationId;
            return (
              <button
                key={form.id}
                onClick={() => handleSelectFormation(form.id)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-amber-400 bg-amber-950/40 text-amber-300 ring-2 ring-amber-400/50 shadow-lg'
                    : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700 hover:bg-slate-800/80'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-heading text-xl font-black tracking-tight">{form.name}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${isSelected ? 'bg-amber-400 text-black' : 'bg-slate-800 text-slate-400'}`}>
                      {form.structure}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 line-clamp-2 leading-snug">
                    {form.description}
                  </p>
                </div>
                <span className="text-[9px] font-bold text-amber-400/90 mt-2 block uppercase">
                  {form.slots.filter(s => s.category === 'DEF').length} DEF · {form.slots.filter(s => s.category === 'MED').length} MED · {form.slots.filter(s => s.category === 'DEL').length} DEL
                </span>
              </button>
            );
          })}
        </div>

        {/* Formation Influence Note */}
        <div className="bg-black/40 border border-slate-800 rounded-xl p-2.5 flex items-start gap-2 text-xs text-slate-300">
          <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p>
            <strong>Influencia en el Draft:</strong> {currentFormation.tacticalInfluence}
          </p>
        </div>
      </div>

      {/* 5-Player Choice Selection Bar when picking */}
      {activeSlot && activeSlotCode && (
        <div className="bg-gradient-to-b from-[#131c17] via-[#0d1410] to-[#090e0b] border-2 border-amber-500/50 rounded-3xl p-5 sm:p-7 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <div>
                <h3 className="font-heading text-2xl sm:text-3xl font-extrabold text-amber-400 uppercase leading-none">
                  Elige tu {activeSlot.label} ({activeSlot.category}) · 5 Opciones al Azar
                </h3>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Rol específico de la formación {currentFormation.structure}: {activeSlot.preferredSubPosition || activeSlot.label}
                </span>
              </div>
            </div>

            {/* Re-roll 5 cards button with strict 3 changes limit */}
            <div className="flex items-center gap-3">
              <button
                onClick={handleManualReroll}
                disabled={rerollsLeft <= 0}
                className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                  rerollsLeft > 0
                    ? 'bg-amber-500 hover:bg-amber-400 text-black font-extrabold shadow-md cursor-pointer'
                    : 'bg-slate-900 border border-slate-800 text-slate-500 cursor-not-allowed opacity-60'
                }`}
                title={rerollsLeft > 0 ? `Gasta 1 cambio (quedan ${rerollsLeft})` : 'Has agotado tus 3 cambios'}
              >
                <Dices className="w-4 h-4 shrink-0" />
                <span>
                  {rerollsLeft > 0
                    ? `Sortear Otras 5 Cartas (${rerollsLeft}/3 cambios restantes)`
                    : 'Sin Cambios Restantes (0/3 usados)'}
                </span>
              </button>
            </div>
          </div>

          {/* Warning if 0 changes left */}
          {rerollsLeft === 0 && (
            <div className="bg-rose-950/40 border border-rose-500/30 rounded-xl px-3 py-1.5 flex items-center gap-2 text-xs text-rose-300">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              <span>Has agotado tus 3 cambios máximos permitidos en este juego. Debes elegir una de las 5 cartas en pantalla.</span>
            </div>
          )}

          {/* 5 Random Cards row */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 justify-items-center pt-2">
            {current5Options.map((player) => (
              <FutCard
                key={player.id}
                player={player}
                onClick={() => handleSelectPlayer(player)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Complete Notification CTA */}
      {isComplete && (
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-amber-950 border-2 border-emerald-400 rounded-3xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-2xl">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 shrink-0" />
            <div>
              <h3 className="font-heading text-3xl font-black text-emerald-300 uppercase">
                ¡PLANTILLA TITULAR LISTA EN ESQUEMA {currentFormation.structure}!
              </h3>
              <p className="text-xs text-slate-200">
                Tu media general es de <strong>{teamOvr} OVR</strong> con <strong>{currentFormation.name}</strong>. Cambios utilizados: {3 - rerollsLeft} de 3.
              </p>
            </div>
          </div>

          <button
            onClick={handleProceedToTournament}
            className="py-3.5 px-8 bg-amber-500 hover:bg-amber-400 text-black font-heading text-2xl font-black rounded-2xl shadow-xl transition-all cursor-pointer flex items-center gap-2 uppercase tracking-wider"
          >
            <span>Elegir Torneo</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Football Pitch Formation View (Adapts to selected formation) */}
      <div className="bg-[#080d0a] border border-amber-500/30 rounded-3xl p-4 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 border-b border-slate-800 pb-3">
          <div>
            <h3 className="font-heading text-2xl font-bold text-slate-200 uppercase tracking-wide">
              Cancha de Juego · Esquema {currentFormation.name}
            </h3>
            <span className="text-xs text-slate-400">
              Toca un puesto vacío para draftear o un jugador fichado para reemplazarlo (gasta 1 cambio si te quedan disponibles).
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 bg-black/60 border border-amber-500/30 px-3 py-1.5 rounded-xl">
            <span>Cambios restantes: {rerollsLeft}/3</span>
          </div>
        </div>

        {/* Soccer pitch container */}
        <div className="relative w-full aspect-[16/11] max-h-[620px] rounded-2xl bg-gradient-to-b from-[#113822] via-[#0d2a19] to-[#0a2013] border-2 border-white/20 p-4 shadow-inner overflow-hidden select-none">
          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-white/20 -translate-y-1/2" />
          <div className="absolute top-1/2 left-1/2 w-36 h-36 rounded-full border border-white/20 -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-24 border-b border-l border-r border-white/20" />
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-64 h-24 border-t border-l border-r border-white/20" />

          {/* 11 Position Slots Placed via Coords according to the chosen formation */}
          {currentFormation.slots.map((slot) => {
            const player = lineup[slot.code];
            const isActive = activeSlotCode === slot.code;

            return (
              <div
                key={slot.code}
                style={{
                  left: `${slot.coords.x}%`,
                  top: `${slot.coords.y}%`,
                  transform: 'translate(-50%, -50%)',
                }}
                className="absolute z-10 flex flex-col items-center"
              >
                {player ? (
                  <div className="group relative">
                    <FutCard
                      player={player}
                      compact
                      isSelected={isActive}
                      onClick={() => {
                        sound.playCardPick();
                        setActiveSlotCode(slot.code);
                      }}
                    />
                    {/* If player already drafted, allow replacing if rerollsLeft > 0 */}
                    {rerollsLeft > 0 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleReplaceDraftedPlayer(slot.code);
                        }}
                        className="hidden group-hover:flex absolute -top-2 -right-2 bg-rose-600 hover:bg-rose-500 text-white rounded-full p-1 shadow-lg text-[9px] font-black cursor-pointer transition-transform hover:scale-110"
                        title="Cambiar este jugador (gasta 1 de tus 3 cambios)"
                      >
                        <RefreshCw className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      sound.playCardPick();
                      setActiveSlotCode(slot.code);
                    }}
                    className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center transition-all cursor-pointer ${
                      isActive
                        ? 'border-amber-400 bg-amber-950/70 text-amber-300 ring-2 ring-amber-400 scale-110 shadow-lg'
                        : 'border-white/30 bg-black/50 text-slate-300 hover:border-amber-400 hover:scale-105'
                    }`}
                  >
                    <span className="font-heading text-lg sm:text-xl font-bold leading-none">
                      {slot.label}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-400 mt-0.5">
                      + Elegir
                    </span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
