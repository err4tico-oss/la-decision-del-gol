import { Player } from '../types/game';
import { Crown, Sparkles } from 'lucide-react';

interface FutCardProps {
  player: Player;
  onClick?: () => void;
  isSelected?: boolean;
  compact?: boolean;
  highlightStat?: 'pace' | 'shooting' | 'passing' | 'dribbling' | 'defending' | 'physical';
}

export function FutCard({ player, onClick, isSelected, compact, highlightStat }: FutCardProps) {
  // Color themes based on tier
  const tierStyles = {
    icon: {
      bg: 'bg-gradient-to-b from-amber-100 via-amber-200 to-amber-400 text-slate-900 border-amber-300 shadow-[0_0_20px_rgba(251,191,36,0.5)]',
      accentText: 'text-amber-900',
      badgeBg: 'bg-amber-900 text-amber-100',
      statLabel: 'text-amber-900',
    },
    gold_rare: {
      bg: 'bg-gradient-to-b from-[#e5c07b] via-[#d19a66] to-[#b87d3b] text-slate-900 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]',
      accentText: 'text-yellow-950',
      badgeBg: 'bg-yellow-950 text-amber-200',
      statLabel: 'text-yellow-950',
    },
    gold_common: {
      bg: 'bg-gradient-to-b from-[#d4af37] via-[#aa8c2c] to-[#7f6920] text-slate-100 border-yellow-600/70',
      accentText: 'text-amber-200',
      badgeBg: 'bg-black/60 text-amber-300',
      statLabel: 'text-amber-100/90',
    },
    silver: {
      bg: 'bg-gradient-to-b from-slate-200 via-slate-400 to-slate-500 text-slate-900 border-slate-300 shadow-[0_0_10px_rgba(148,163,184,0.3)]',
      accentText: 'text-slate-900',
      badgeBg: 'bg-slate-800 text-slate-100',
      statLabel: 'text-slate-900',
    },
    bronze: {
      bg: 'bg-gradient-to-b from-[#925436] via-[#753d22] to-[#4e2513] text-amber-100 border-[#b5653b]',
      accentText: 'text-amber-300',
      badgeBg: 'bg-black/60 text-amber-200',
      statLabel: 'text-amber-200/90',
    },
  }[player.tier];

  if (compact) {
    return (
      <div
        onClick={onClick}
        className={`relative w-20 sm:w-24 p-1.5 rounded-xl border transition-all cursor-pointer select-none text-center ${tierStyles.bg} ${
          isSelected ? 'ring-2 ring-amber-400 scale-105' : 'hover:scale-105'
        }`}
      >
        <div className="flex items-center justify-between text-[11px] font-bold leading-none mb-1">
          <span className="font-heading text-lg font-black tabular-nums">{player.ovr}</span>
          <span className="text-[10px] font-bold px-1 py-0.2 rounded bg-black/40 text-white">
            {player.position}
          </span>
        </div>
        <p className="text-xs font-black truncate leading-tight">{player.shortName}</p>
        <p className="text-[10px] truncate opacity-80">{player.club}</p>
      </div>
    );
  }

  return (
    <div
      onClick={onClick}
      className={`relative w-full max-w-[210px] p-3 rounded-2xl border-2 transition-all duration-200 select-none cursor-pointer flex flex-col justify-between ${tierStyles.bg} ${
        isSelected
          ? 'ring-4 ring-amber-400 scale-105 shadow-2xl'
          : 'hover:scale-[1.03] hover:shadow-xl'
      }`}
    >
      {player.tier === 'icon' && (
        <div className="absolute -top-2.5 right-3 bg-amber-950 text-amber-300 border border-amber-400/80 px-2 py-0.5 rounded-full flex items-center gap-1 text-[9px] font-black tracking-widest uppercase shadow-md animate-pulse">
          <Crown className="w-3 h-3 text-amber-400" />
          <span>ÍCONO</span>
        </div>
      )}

      {/* Top Header: OVR, Position, Nationality */}
      <div className="flex items-start justify-between">
        <div className="flex flex-col items-center">
          <span className="font-heading text-4xl sm:text-5xl font-black leading-none tracking-tight tabular-nums">
            {player.ovr}
          </span>
          <span className={`text-xs font-black px-1.5 py-0.5 rounded tracking-wider uppercase mt-0.5 ${tierStyles.badgeBg}`}>
            {player.position}
          </span>
          <span className="text-xl mt-1" title={player.nationality}>
            {player.flag}
          </span>
        </div>

        {/* Club Tag */}
        <div className="text-right">
          <span className="text-[10px] font-bold uppercase tracking-wider block opacity-90 truncate max-w-[90px]">
            {player.league}
          </span>
          <span className="text-xs font-black truncate block max-w-[90px]">
            {player.club}
          </span>
        </div>
      </div>

      {/* Center: Player Full/Short Name */}
      <div className="my-3 text-center border-t border-b border-black/15 py-1.5">
        <h4 className="font-black text-sm sm:text-base tracking-tight truncate leading-tight uppercase">
          {player.shortName}
        </h4>
        <span className="text-[10px] font-semibold opacity-80 block truncate">
          {player.name}
        </span>
      </div>

      {/* 6 FUT Key Stats */}
      <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-xs">
        <div className={`flex items-center justify-between px-1.5 py-0.5 rounded ${highlightStat === 'pace' ? 'bg-amber-500/40 font-bold' : ''}`}>
          <span className={`text-[10px] font-bold uppercase ${tierStyles.statLabel}`}>PAC</span>
          <span className="font-black tabular-nums">{player.pace}</span>
        </div>
        <div className={`flex items-center justify-between px-1.5 py-0.5 rounded ${highlightStat === 'dribbling' ? 'bg-amber-500/40 font-bold' : ''}`}>
          <span className={`text-[10px] font-bold uppercase ${tierStyles.statLabel}`}>REG</span>
          <span className="font-black tabular-nums">{player.dribbling}</span>
        </div>
        <div className={`flex items-center justify-between px-1.5 py-0.5 rounded ${highlightStat === 'shooting' ? 'bg-amber-500/40 font-bold' : ''}`}>
          <span className={`text-[10px] font-bold uppercase ${tierStyles.statLabel}`}>TIR</span>
          <span className="font-black tabular-nums">{player.shooting}</span>
        </div>
        <div className={`flex items-center justify-between px-1.5 py-0.5 rounded ${highlightStat === 'defending' ? 'bg-amber-500/40 font-bold' : ''}`}>
          <span className={`text-[10px] font-bold uppercase ${tierStyles.statLabel}`}>DEF</span>
          <span className="font-black tabular-nums">{player.defending}</span>
        </div>
        <div className={`flex items-center justify-between px-1.5 py-0.5 rounded ${highlightStat === 'passing' ? 'bg-amber-500/40 font-bold' : ''}`}>
          <span className={`text-[10px] font-bold uppercase ${tierStyles.statLabel}`}>PAS</span>
          <span className="font-black tabular-nums">{player.passing}</span>
        </div>
        <div className={`flex items-center justify-between px-1.5 py-0.5 rounded ${highlightStat === 'physical' ? 'bg-amber-500/40 font-bold' : ''}`}>
          <span className={`text-[10px] font-bold uppercase ${tierStyles.statLabel}`}>FIS</span>
          <span className="font-black tabular-nums">{player.physical}</span>
        </div>
      </div>

      {onClick && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onClick();
          }}
          className="mt-2.5 w-full py-1 text-[11px] font-black uppercase tracking-wider rounded-lg bg-black text-amber-300 hover:bg-black/80 transition-colors cursor-pointer"
        >
          Elegir Carta
        </button>
      )}
    </div>
  );
}
