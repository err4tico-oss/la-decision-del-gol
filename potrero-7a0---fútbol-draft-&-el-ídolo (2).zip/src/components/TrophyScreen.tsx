import { useEffect } from 'react';
import { TournamentType } from '../types/game';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';
import { Trophy, Globe, Award, Sparkles, RefreshCw } from 'lucide-react';

interface TrophyScreenProps {
  tournamentType: TournamentType;
  teamOvr: number;
  onNewDraft: () => void;
}

export function TrophyScreen({ tournamentType, teamOvr, onNewDraft }: TrophyScreenProps) {
  useEffect(() => {
    sound.playGoalRoar();
    confetti({
      particleCount: 200,
      spread: 120,
      origin: { y: 0.5 },
    });
  }, []);

  const isChampions = tournamentType === 'champions';

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8 py-10 text-center animate-in zoom-in-95 duration-300">
      <div className="relative inline-block">
        <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 flex items-center justify-center mx-auto shadow-[0_0_60px_rgba(245,158,11,0.6)] animate-bounce">
          {isChampions ? (
            <Trophy className="w-16 h-16 sm:w-20 sm:h-20 text-black" />
          ) : (
            <Globe className="w-16 h-16 sm:w-20 sm:h-20 text-black" />
          )}
        </div>
      </div>

      <div className="space-y-3">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block">
          ¡CAMPEÓN INVICTO DEL TORNEO!
        </span>
        <h1 className="font-heading text-5xl sm:text-7xl font-black text-slate-100 uppercase tracking-tight">
          {isChampions ? '¡CAMPEÓN DE LA UEFA CHAMPIONS LEAGUE!' : '¡CAMPEÓN DE LA COPA DEL MUNDO!'}
        </h1>
        <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto leading-relaxed">
          Tu plantilla de 11 estrellas (Media <strong>{teamOvr} OVR</strong>) tomó las decisiones tácticas correctas en las 5 situaciones clave de cada partido y alcanzó la gloria máxima.
        </p>
      </div>

      <div className="pt-4">
        <button
          onClick={onNewDraft}
          className="py-4 px-10 bg-amber-500 hover:bg-amber-400 text-black font-heading text-2xl font-bold uppercase tracking-wider rounded-2xl shadow-2xl transition-all cursor-pointer inline-flex items-center gap-2"
        >
          <RefreshCw className="w-5 h-5" />
          <span>Comenzar Nuevo FUT Draft</span>
        </button>
      </div>
    </div>
  );
}
