import { CampaignMatch, TournamentType } from '../types/game';
import { Play, Dices, Trophy, Globe, CheckCircle2, XCircle } from 'lucide-react';

interface BracketViewProps {
  tournamentType: TournamentType;
  matches: CampaignMatch[];
  currentMatchIndex: number;
  userTeamOvr: number;
  points: number;
  onStartMatch: () => void;
  onResetTournament: () => void;
}

export function BracketView({
  tournamentType,
  matches,
  currentMatchIndex,
  userTeamOvr,
  points,
  onStartMatch,
  onResetTournament,
}: BracketViewProps) {
  const isChampions = tournamentType === 'champions';
  const totalMatches = isChampions ? 15 : 8;
  const currentMatch = matches[currentMatchIndex];

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block mb-1 flex items-center gap-1.5">
            {isChampions ? <Trophy className="w-4 h-4 text-blue-400" /> : <Globe className="w-4 h-4 text-amber-400" />}
            <span>{isChampions ? 'UEFA Champions League (15 Partidos)' : 'Copa del Mundo FIFA (8 Partidos)'}</span>
          </span>
          <h2 className="font-heading text-4xl sm:text-5xl font-black text-slate-100 uppercase tracking-tight">
            Campaña Hacia la Gran Final
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[11px] font-bold text-slate-400 block uppercase">Puntos Acumulados</span>
            <span className="font-heading text-3xl font-black text-amber-400 tabular-nums leading-none">
              {points} pts
            </span>
          </div>
          <button
            onClick={onResetTournament}
            className="text-xs text-slate-400 hover:text-white bg-slate-800 px-3 py-2 rounded-xl cursor-pointer"
          >
            Nuevo Draft
          </button>
        </div>
      </div>

      {/* NEWLY DRAWN RIVAL SHOWCASE CARD */}
      {currentMatch && (
        <div className="bg-gradient-to-r from-slate-950 via-[#121c15] to-slate-950 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-5">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
              <Dices className="w-4 h-4 text-amber-400" />
              <span>Sorteo a Ciegas Realizado · {currentMatch.stageInfo.phaseName}</span>
            </div>
            <span className="text-xs font-mono font-bold text-slate-400 tabular-nums">
              Partido {currentMatchIndex + 1} de {totalMatches}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center text-center">
            {/* User */}
            <div className="p-4 rounded-2xl bg-black/40 border border-slate-800">
              <span className="text-[11px] font-bold text-slate-400 block uppercase">Tu Plantilla FUT</span>
              <h4 className="font-heading text-3xl font-bold text-amber-400 uppercase mt-1">Mi Equipo</h4>
              <span className="text-xs font-semibold text-slate-300">OVR {userTeamOvr}</span>
            </div>

            {/* VS Badge */}
            <div className="space-y-1">
              <span className="font-heading text-3xl font-black text-slate-500 uppercase">VS</span>
              <span className="block text-[11px] text-amber-400/90 font-semibold">
                {currentMatch.stageInfo.isKnockout ? 'Eliminatoria Directa' : 'Fase Regular por Puntos'}
              </span>
            </div>

            {/* Random Rival Drawn */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-amber-500/40">
              <span className="text-[11px] font-bold text-amber-400 block uppercase">Rival Sorteado al Azar</span>
              <div className="flex items-center justify-center gap-2 mt-1">
                <span className="text-2xl">{currentMatch.rival.logoEmoji}</span>
                <h4 className="font-heading text-3xl font-bold text-slate-100 uppercase truncate">
                  {currentMatch.rival.name}
                </h4>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                Media: <strong className="text-amber-400">OVR {currentMatch.rival.ovr}</strong> · Figura: {currentMatch.rival.starPlayer}
              </p>
            </div>
          </div>

          <div className="mt-6 flex justify-center">
            <button
              onClick={onStartMatch}
              className="py-3.5 px-10 bg-amber-500 hover:bg-amber-400 text-black font-heading text-2xl font-black uppercase tracking-wider rounded-2xl shadow-xl transition-all cursor-pointer flex items-center gap-2"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>Jugar Este Partido (5 Jugadas Clave)</span>
            </button>
          </div>
        </div>
      )}

      {/* MATCH SCHEDULE TIMELINE */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="font-bold uppercase tracking-wider">Cronograma de la Campaña Oficial</span>
          <span>Los rivales futuros se sortean al azar al terminar cada partido</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {matches.map((match, idx) => {
            const isPlayed = match.isPlayed;
            const isCurrent = idx === currentMatchIndex && !isPlayed;
            const isFuture = idx > currentMatchIndex;

            return (
              <div
                key={idx}
                className={`p-3.5 rounded-2xl border text-xs flex flex-col justify-between ${
                  isCurrent
                    ? 'border-amber-400 bg-amber-950/40 text-amber-200 ring-2 ring-amber-400/40'
                    : isPlayed && match.won
                    ? 'border-emerald-500/50 bg-emerald-950/20 text-emerald-200'
                    : isPlayed && !match.won
                    ? 'border-red-500/50 bg-red-950/20 text-red-200'
                    : 'border-slate-800 bg-slate-950/40 text-slate-500'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1 text-[11px] font-bold">
                    <span>P{idx + 1} · {match.stageInfo.phaseName}</span>
                    {isPlayed && (match.won ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-red-400" />)}
                  </div>

                  <div className="my-2">
                    {isFuture ? (
                      <p className="font-semibold text-slate-500 italic flex items-center gap-1.5">
                        <Dices className="w-3.5 h-3.5 text-slate-600" />
                        <span>Rival a sortear al azar</span>
                      </p>
                    ) : (
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-200 truncate">
                          {match.rival.logoEmoji} {match.rival.shortName}
                        </span>
                        {isPlayed && (
                          <span className="font-mono font-bold text-amber-400 tabular-nums">
                            {match.userScore} - {match.rivalScore}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800/60">
                  {isCurrent ? '⚡ En disputa ahora' : isPlayed ? 'Completado' : 'Próximo partido'}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
