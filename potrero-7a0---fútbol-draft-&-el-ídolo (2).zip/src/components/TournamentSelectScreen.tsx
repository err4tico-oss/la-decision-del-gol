import { TournamentType } from '../types/game';
import { sound } from '../utils/audio';
import { Trophy, Globe, ArrowRight, Dices } from 'lucide-react';

interface TournamentSelectScreenProps {
  userTeamOvr: number;
  onSelectTournament: (type: TournamentType) => void;
  onBackToDraft: () => void;
}

export function TournamentSelectScreen({
  userTeamOvr,
  onSelectTournament,
  onBackToDraft,
}: TournamentSelectScreenProps) {
  const handleSelect = (type: TournamentType) => {
    sound.playWhistle();
    onSelectTournament(type);
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-8 pb-12">
      <div className="text-center space-y-2">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block">
          Paso 2 · Selección de Torneo Oficial
        </span>
        <h2 className="font-heading text-4xl sm:text-6xl font-black text-slate-100 uppercase tracking-tight">
          Elige tu Campaña Oficial
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Tu plantilla (Media <strong>{userTeamOvr} OVR</strong>) competirá bajo los calendarios reglamentarios. Los rivales se sortearán <strong>100% al azar a ciegas</strong> al concluir cada encuentro.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Mundial 8 Partidos */}
        <div
          onClick={() => handleSelect('mundial')}
          className="relative group rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-[#251b0a] via-[#161105] to-[#0c0903] border-2 border-amber-500/40 hover:border-amber-400 transition-all duration-300 hover:scale-[1.02] cursor-pointer shadow-2xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="px-3 py-1 bg-amber-950/80 border border-amber-400 text-amber-300 text-xs font-bold rounded-lg uppercase tracking-wider flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-amber-400" />
                Mundial de 48 Selecciones
              </span>
              <span className="text-xs font-bold text-amber-400 bg-amber-900/60 px-2.5 py-1 rounded-full tabular-nums">
                8 Partidos Oficiales
              </span>
            </div>

            <h3 className="font-heading text-4xl sm:text-5xl font-black text-amber-400 tracking-tight uppercase leading-none">
              Copa del Mundo FIFA
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              El camino completo del finalista bajo el formato de 48 selecciones: 3 partidos de Fase de Grupos + Dieciseisavos de final + Octavos + Cuartos + Semifinal + Gran Final.
            </p>

            <div className="mt-5 p-4 rounded-2xl bg-black/40 border border-amber-500/20 space-y-2 text-xs text-slate-300">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <Dices className="w-4 h-4" />
                <span>Sorteo a Ciegas:</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Cada rival se sorteará de forma imprevista entre más de 24 selecciones internacionales al terminar el partido previo.
              </p>
            </div>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              handleSelect('mundial');
            }}
            className="w-full mt-6 py-3.5 px-5 bg-amber-500 hover:bg-amber-400 text-black font-heading text-2xl font-bold uppercase tracking-wider rounded-xl shadow-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Disputar el Mundial (8 Partidos)</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Champions League 15 Partidos */}
        <div
          onClick={() => handleSelect('champions')}
          className="relative group rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-[#0b1736] via-[#091024] to-[#040813] border-2 border-blue-500/40 hover:border-blue-400 transition-all duration-300 hover:scale-[1.02] cursor-pointer shadow-2xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="px-3 py-1 bg-blue-950/80 border border-blue-400 text-blue-300 text-xs font-bold rounded-lg uppercase tracking-wider flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-blue-400" />
                UEFA Champions League
              </span>
              <span className="text-xs font-bold text-blue-300 bg-blue-900/60 px-2.5 py-1 rounded-full tabular-nums">
                15 Partidos Oficiales
              </span>
            </div>

            <h3 className="font-heading text-4xl sm:text-5xl font-black text-white tracking-tight uppercase leading-none">
              Champions League
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              El formato de 36 clubes europeos: 8 jornadas de Fase de Liga única + Octavos (ida y vuelta) + Cuartos (ida y vuelta) + Semifinales (ida y vuelta) + Gran Final.
            </p>

            <div className="mt-5 p-4 rounded-2xl bg-black/40 border border-blue-500/20 space-y-2 text-xs text-slate-300">
              <div className="flex items-center gap-2 text-blue-400 font-bold">
                <Dices className="w-4 h-4" />
                <span>Sorteo a Ciegas:</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Nunca sabrás contra qué gigante europeo jugarás hasta que finalice tu partido anterior y las bolillas del sorteo elijan al rival.
              </p>
            </div>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              handleSelect('champions');
            }}
            className="w-full mt-6 py-3.5 px-5 bg-blue-500 hover:bg-blue-400 text-black font-heading text-2xl font-bold uppercase tracking-wider rounded-xl shadow-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Jugar la Champions (15 Partidos)</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="text-center pt-2">
        <button
          onClick={onBackToDraft}
          className="text-xs font-semibold text-slate-400 hover:text-slate-200 underline cursor-pointer"
        >
          ← Volver a modificar mi plantilla de 11 jugadores
        </button>
      </div>
    </div>
  );
}
