export type PositionCode = string;

export type PositionCategory = 'POR' | 'DEF' | 'MED' | 'DEL';

export interface Player {
  id: string;
  name: string;
  shortName: string;
  position: 'POR' | 'LI' | 'DFC' | 'LD' | 'MC' | 'MCD' | 'MCO' | 'EI' | 'ED' | 'DC';
  category: PositionCategory;
  ovr: number; // 64 to 97
  tier: 'icon' | 'gold_rare' | 'gold_common' | 'silver' | 'bronze';
  club: string;
  league: string;
  nationality: string;
  flag: string;
  pace: number;
  shooting: number;
  passing: number;
  dribbling: number;
  defending: number;
  physical: number;
}

export interface FormationSlot {
  code: string;
  label: string;
  category: PositionCategory;
  preferredSubPosition?: 'POR' | 'LI' | 'DFC' | 'LD' | 'MC' | 'MCD' | 'MCO' | 'EI' | 'ED' | 'DC';
  coords: { x: number; y: number };
}

export interface TacticalFormation {
  id: string;
  name: string;
  structure: string; // e.g. "4-3-3", "4-4-2", "3-5-2", "4-2-3-1", "5-3-2"
  tagline: string;
  description: string;
  slots: FormationSlot[];
  tacticalInfluence: string; // How this formation influences player cards & tactics
}

export type TournamentType = 'mundial' | 'champions';

export interface TournamentTeam {
  id: string;
  name: string;
  shortName: string;
  ovr: number;
  logoEmoji: string;
  countryOrCity: string;
  starPlayer: string;
  color: string;
}

export interface MatchStageInfo {
  matchNumber: number; // e.g. 1 to 8 (Mundial) or 1 to 15 (Champions)
  totalMatches: number;
  phaseName: string; // e.g. "Fase de Grupos - Jornada 1", "Dieciseisavos de Final", "Fase de Liga - Fecha 4"
  isKnockout: boolean; // if true, draw requires penalties
  leg?: 'ida' | 'vuelta' | 'unica';
  aggregateUser?: number;
  aggregateRival?: number;
}

export type SituationZone = 'ataque' | 'defensa' | 'mediocampo';

export interface SituationOption {
  id: string;
  title: string;
  description: string;
  // NOTE: Risk is kept internal for math calculations only, NEVER shown to user
  internalRiskWeight: number; // 0.45 to 0.85
  statRequired: 'pace' | 'shooting' | 'passing' | 'dribbling' | 'defending' | 'physical';
  outcomeSuccess: {
    text: string;
    pointsGoal: number;
    flavor: string;
  };
  outcomeFail: {
    text: string;
    pointsConceded: number;
    flavor: string;
  };
}

export interface MatchSituation {
  id: string;
  minute: number;
  zone: SituationZone;
  title: string;
  scenarioText: string;
  playerInvolved?: string;
  options: [SituationOption, SituationOption, SituationOption]; // Exactly 3 options, no risk labels
}

export interface CampaignMatch {
  matchIndex: number;
  stageInfo: MatchStageInfo;
  rival: TournamentTeam;
  isPlayed: boolean;
  userScore?: number;
  rivalScore?: number;
  won?: boolean;
}
