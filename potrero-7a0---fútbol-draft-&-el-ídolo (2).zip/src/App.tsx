/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Player, PositionCode, TournamentType, CampaignMatch } from './types/game';
import {
  MUNDIAL_SCHEDULE,
  CHAMPIONS_SCHEDULE,
  drawRandomRival,
} from './data/tournamentData';
import { Header } from './components/Header';
import { DraftScreen } from './components/DraftScreen';
import { TournamentSelectScreen } from './components/TournamentSelectScreen';
import { BracketView } from './components/BracketView';
import { MatchEngineScreen } from './components/MatchEngineScreen';
import { TrophyScreen } from './components/TrophyScreen';

type AppStage = 'draft' | 'tournament_select' | 'bracket' | 'match' | 'trophy';

export default function App() {
  const [stage, setStage] = useState<AppStage>('draft');

  // Drafted team
  const [lineup, setLineup] = useState<Record<string, Player | null>>({});
  const [teamOvr, setTeamOvr] = useState<number>(0);
  const [formationId, setFormationId] = useState<string>('4-3-3');

  // Tournament campaign state
  const [tournamentType, setTournamentType] = useState<TournamentType>('mundial');
  const [matches, setMatches] = useState<CampaignMatch[]>([]);
  const [currentMatchIndex, setCurrentMatchIndex] = useState<number>(0);
  const [points, setPoints] = useState<number>(0);

  // Handle draft completion (all 11 slots picked)
  const handleDraftComplete = (team: {
    lineup: Record<string, Player | null>;
    ovr: number;
    formationId: string;
  }) => {
    setLineup(team.lineup);
    setTeamOvr(team.ovr);
    setFormationId(team.formationId);
    setStage('tournament_select');
  };

  // Handle tournament format selection (Champions 15 or Mundial 8)
  const handleSelectTournament = (type: TournamentType) => {
    setTournamentType(type);
    setPoints(0);

    const schedule = type === 'champions' ? CHAMPIONS_SCHEDULE : MUNDIAL_SCHEDULE;
    const totalMatches = schedule.length;

    // Draw the FIRST rival at random
    const firstRival = drawRandomRival(type, []);

    // Create the match schedule array; upcoming rivals are left empty until drawn!
    const initialMatches: CampaignMatch[] = schedule.map((sch, idx) => ({
      matchIndex: idx,
      stageInfo: {
        matchNumber: idx + 1,
        totalMatches,
        phaseName: sch.stageName,
        isKnockout: sch.isKnockout,
      },
      rival: idx === 0 ? firstRival : drawRandomRival(type, []), // Default placeholder, re-drawn dynamically
      isPlayed: false,
    }));

    setMatches(initialMatches);
    setCurrentMatchIndex(0);
    setStage('bracket');
  };

  // Start match
  const handleStartMatch = () => {
    setStage('match');
  };

  // Handle match finish
  const handleMatchComplete = (result: {
    userScore: number;
    rivalScore: number;
    won: boolean;
    isDraw?: boolean;
  }) => {
    const isWin = result.won;
    const isDraw = result.isDraw;

    // Points calculation (3 win, 1 draw)
    if (isWin) setPoints((p) => p + 3);
    else if (isDraw) setPoints((p) => p + 1);

    // Update match record
    setMatches((prev) => {
      const copy = [...prev];
      if (copy[currentMatchIndex]) {
        copy[currentMatchIndex] = {
          ...copy[currentMatchIndex],
          isPlayed: true,
          userScore: result.userScore,
          rivalScore: result.rivalScore,
          won: isWin || (isDraw && !copy[currentMatchIndex].stageInfo.isKnockout),
        };
      }
      return copy;
    });

    const isKnockout = matches[currentMatchIndex]?.stageInfo.isKnockout;
    const canAdvance = isWin || (!isKnockout && (isDraw || points + (isWin ? 3 : isDraw ? 1 : 0) >= 3));

    if (canAdvance) {
      const nextIdx = currentMatchIndex + 1;
      const totalMatches = tournamentType === 'champions' ? 15 : 8;

      if (nextIdx < totalMatches) {
        // DRAW NEXT RIVAL AT RANDOM A CIEGAS!
        const alreadyPlayedRivals = matches
          .slice(0, nextIdx)
          .map((m) => m.rival.id);
        const newRival = drawRandomRival(tournamentType, alreadyPlayedRivals);

        setMatches((prev) => {
          const copy = [...prev];
          if (copy[nextIdx]) {
            copy[nextIdx] = {
              ...copy[nextIdx],
              rival: newRival,
            };
          }
          return copy;
        });

        setCurrentMatchIndex(nextIdx);
        setStage('bracket');
      } else {
        // CHAMPION OF THE TOURNAMENT! (Finished all 8 or 15 matches)
        setStage('trophy');
      }
    } else {
      // Stay on bracket to show elimination
      setStage('bracket');
    }
  };

  // Reset entire game
  const handleResetGame = () => {
    setStage('draft');
    setLineup({
      POR: null,
      LI: null,
      DFC1: null,
      DFC2: null,
      LD: null,
      MC1: null,
      MC2: null,
      MCO: null,
      EI: null,
      DC: null,
      ED: null,
    });
    setTeamOvr(0);
    setMatches([]);
    setCurrentMatchIndex(0);
    setPoints(0);
  };

  const currentMatch = matches[currentMatchIndex];

  return (
    <div className="min-h-screen bg-[#070b09] text-[#f1f5f9] flex flex-col font-sans selection:bg-amber-500 selection:text-black">
      {/* 3-Zone Header Contract */}
      <Header currentStage={stage} teamOvr={teamOvr} onReset={handleResetGame} />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {stage === 'draft' && (
          <DraftScreen onDraftComplete={handleDraftComplete} />
        )}

        {stage === 'tournament_select' && (
          <TournamentSelectScreen
            userTeamOvr={teamOvr}
            onSelectTournament={handleSelectTournament}
            onBackToDraft={() => setStage('draft')}
          />
        )}

        {stage === 'bracket' && (
          <BracketView
            tournamentType={tournamentType}
            matches={matches}
            currentMatchIndex={currentMatchIndex}
            userTeamOvr={teamOvr}
            points={points}
            onStartMatch={handleStartMatch}
            onResetTournament={handleResetGame}
          />
        )}

        {stage === 'match' && currentMatch && (
          <MatchEngineScreen
            userTeamOvr={teamOvr}
            userSquad={{
              delantero: Object.values(lineup).find((p): p is Player => p?.category === 'DEL'),
              mediocampista: Object.values(lineup).find((p): p is Player => p?.category === 'MED'),
              defensa: Object.values(lineup).find((p): p is Player => p?.category === 'DEF'),
              portero: Object.values(lineup).find((p): p is Player => p?.category === 'POR'),
            }}
            rivalTeam={currentMatch.rival}
            stageInfo={currentMatch.stageInfo}
            onMatchComplete={handleMatchComplete}
          />
        )}

        {stage === 'trophy' && (
          <TrophyScreen
            tournamentType={tournamentType}
            teamOvr={teamOvr}
            onNewDraft={handleResetGame}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-slate-800/80 bg-[#040806] py-5 px-4 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>LA DECISIÓN DEL GOL · Campañas Oficiales</p>
          <div className="flex items-center gap-3 text-slate-300">
            <span>Mundial (8 Partidos)</span>
            <span>·</span>
            <span>Champions League (15 Partidos)</span>
            <span>·</span>
            <span>5 Decisiones Clave por Partido</span>
            <span>·</span>
            <span className="text-amber-400 font-semibold">100% en Español</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
